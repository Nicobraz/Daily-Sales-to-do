import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {test} from 'node:test';
import {handleRequest,localDate} from '../worker/api.js';
import {openLocalD1} from '../scripts/sqlite-d1.mjs';

const originalSchema=await readFile(new URL('../drizzle/0000_calendar_tasks.sql',import.meta.url),'utf8');
const migration=await readFile(new URL('../drizzle/0001_review_imports.sql',import.meta.url),'utf8');
const schedulingMigration=await readFile(new URL('../drizzle/0002_task_scheduling.sql',import.meta.url),'utf8');
const ORIGIN='https://pss-morning-sales.vigilantbanjo.chatgpt.site';
function setup(t,{migrate=true}={}) {
  const db=openLocalD1(':memory:'); db.sqlite.exec(originalSchema);
  if (migrate) { db.sqlite.exec(migration); db.sqlite.exec(schedulingMigration); }
  t.after(() => db.close());
  return db;
}
function call(db,path,{method='GET',body,owner='nico-owner',headers={},raw}={}) {
  const h={...headers};
  if (owner!==null) h['oai-authenticated-user-id']=owner;
  if (body!==undefined && !Object.hasOwn(h,'content-type')) h['content-type']='application/json';
  return handleRequest(new Request(ORIGIN+path,{method,headers:h,body:raw ?? (body!==undefined ? JSON.stringify(body) : undefined)}),{DB:db},'<html>Private calendar</html>');
}
async function jsonOk(response,status=200) {
  const r=await response;
  const b=await r.json();
  assert.equal(r.status,status,JSON.stringify(b)); return b;
}
const lead=(overrides={})=>({source_system:'Wingmate',source_record:'lead-001',contact:'Test Contact',company:'Example Company',rep:'Nico Braswell',why:'Requested a quote',next_action:'Review estimate',message:'Following up on your estimate.',...overrides});
const review=(db,tasks,options={})=>call(db,'/api/import-review',{method:'POST',body:{tasks},...options});
const list=(db,owner)=>jsonOk(call(db,'/api/tasks',{owner}));
const create=(db,body,options={})=>jsonOk(call(db,'/api/tasks',{method:'POST',body,...options}),201);

test('private HTML/API require the existing platform owner and never trust a body owner',async t=>{
  const db=setup(t);
  assert.equal((await call(db,'/',{owner:null})).status,401);
  assert.equal((await call(null,'/',{owner:null})).status,401);
  assert.equal((await call(db,'/api/tasks',{owner:null})).status,401);
  assert.equal((await review(db,[lead()],{owner:null})).status,401);
  const page=await call(db,'/');
  assert.equal(page.status,200); assert.match(page.headers.get('cache-control'),/private/);
  const row=await create(db,{contact:'Private task',user_id:'someone-else'});
  assert.equal(row.contact,'Private task');
  assert.equal((await list(db,'someone-else')).length,0);
  assert.equal((await list(db,'nico-owner')).length,1);
});

test('manual creation defaults to Denver today, stores complete context, and allows partial edits',async t=>{
  const db=setup(t);
  const row=await create(db,{contact:'Prospect',company:'Company',last_interaction_date:'2026-10-31',url:'https://example.com/lead/1',extra_url:'https://example.com/email/1',phone:'+13035550123'});
  assert.equal(row.due_date,localDate()); assert.equal(row.rep,'Nico Braswell');
  const saved=await jsonOk(call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{status:'sold'}}));
  assert.equal(saved.status,'sold'); assert.equal(saved.company,'Company');
  assert.equal(saved.last_interaction_date,'2026-10-31'); assert.equal(saved.extra_url,'https://example.com/email/1');
  assert.equal(saved.phone,'+13035550123');
  assert.equal(db.sqlite.prepare('SELECT status_manual FROM tasks').get().status_manual,1);
});

test('one owner cannot read, edit, delete, or collide with another owner’s task identities',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead()])); await jsonOk(review(db,[lead({contact:'Other owner'})],{owner:'another-owner'}));
  const first=(await list(db,'nico-owner'))[0];
  assert.equal((await list(db,'another-owner'))[0].contact,'Other owner');
  assert.equal((await call(db,'/api/tasks/'+first.id,{method:'PATCH',body:{status:'done'},owner:'another-owner'})).status,404);
  assert.equal((await call(db,'/api/tasks/'+first.id,{method:'DELETE',owner:'another-owner'})).status,404);
  assert.equal((await list(db,'nico-owner'))[0].status,'open');
});

test('writes reject foreign origins, cross-site requests without Origin, non-JSON and malformed JSON',async t=>{
  const db=setup(t);
  assert.equal((await review(db,[lead()],{headers:{origin:'https://attacker.example'}})).status,403);
  assert.equal((await review(db,[lead()],{headers:{'sec-fetch-site':'cross-site'}})).status,403);
  assert.equal((await review(db,[lead()],{headers:{'content-type':'text/plain'}})).status,400);
  assert.equal((await call(db,'/api/tasks',{method:'POST',raw:'not json',headers:{'content-type':'application/json'}})).status,400);
  assert.equal((await list(db)).length,0);
  assert.equal((await review(db,[lead()],{headers:{origin:ORIGIN}})).status,200);
});

test('validation rejects impossible dates, unsafe URLs, unknown status and oversized bodies',async t=>{
  const db=setup(t);
  for (const patch of [{due_date:'2026-02-30'},{due_date:'2026-13-01'},{last_interaction_date:'2025-02-29'},{url:'javascript:alert(1)'},{url:'https://user:secret@example.com/'},{status:'cancelled'},{priority:'Super high'},{date_inferred:1}]) {
    assert.equal((await call(db,'/api/tasks',{method:'POST',body:{contact:'Test',...patch}})).status,400,JSON.stringify(patch));
  }
  assert.equal((await call(db,'/api/tasks',{method:'POST',body:{contact:'Test',why:'x'.repeat(500_001)}})).status,400);
  assert.equal((await create(db,{contact:'Leap day',due_date:'2028-02-29'})).due_date,'2028-02-29');
});

test('review imports default due today with inferred timing and stable source key',async t=>{
  const db=setup(t);
  assert.deepEqual(await jsonOk(review(db,[lead()])),{created:1,updated:0,skipped_deleted:0,total:1});
  let [row]=await list(db);
  const id=row.id;
  assert.equal(row.due_date,localDate()); assert.equal(row.date_inferred,true); assert.match(row.timing_note,/default/);
  assert.equal(db.sqlite.prepare('SELECT due_date_manual,status_manual FROM tasks').get().due_date_manual,0);
  assert.deepEqual(await jsonOk(review(db,[lead({source_system:'wingmate',message:'Updated recommendation',last_interaction_date:'2026-11-01'})])),{created:0,updated:1,skipped_deleted:0,total:1});
  [row]=await list(db);
  assert.equal(row.id,id); assert.equal(row.message,'Updated recommendation'); assert.equal(row.last_interaction_date,'2026-11-01');
  await jsonOk(review(db,[lead({message:'Next review omits interaction date'})]));
  assert.equal((await list(db))[0].last_interaction_date,'2026-11-01');
});

test('fresh reviews refresh details and automatic dates but preserve owner date/status overrides',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({due_date:'2026-11-05'})]));
  const id=(await list(db))[0].id;
  await jsonOk(review(db,[lead({due_date:'2026-11-06'})]));
  assert.equal((await list(db))[0].due_date,'2026-11-06');
  await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-15',status:'not_happening'}}));
  await jsonOk(review(db,[lead({due_date:'2026-11-07',status:'open',message:'Updated details',last_interaction_date:'2026-11-04'})]));
  const [row]=await list(db);
  assert.equal(row.due_date,'2026-12-15'); assert.equal(row.status,'not_happening');
  assert.equal(row.date_inferred,false); assert.match(row.timing_note,/manually/);
  assert.equal(row.message,'Updated details'); assert.equal(row.last_interaction_date,'2026-11-04');
});

test('owner date protection preserves explicit inferred timing labels, while a plain Move clears inference',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({due_date:'2026-11-05'})]));
  const id=(await list(db))[0].id;
  let saved=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-10',date_inferred:true,timing_note:'Inferred from the review; no customer commitment.'}}));
  assert.equal(saved.date_inferred,true); assert.equal(saved.timing_note,'Inferred from the review; no customer commitment.');
  assert.equal(db.sqlite.prepare('SELECT due_date_manual FROM tasks').get().due_date_manual,1);
  await jsonOk(review(db,[lead({due_date:'2026-11-06',timing_note:'Different source schedule'})]));
  let [row]=await list(db);
  assert.equal(row.due_date,'2026-12-10'); assert.equal(row.date_inferred,true); assert.equal(row.timing_note,saved.timing_note);
  saved=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-11'}}));
  assert.equal(saved.date_inferred,false); assert.equal(saved.timing_note,'Date chosen manually.');
  assert.equal((await call(db,'/api/tasks/'+id,{method:'PATCH',body:{date_inferred:true,timing_note:''}})).status,400);
  assert.equal((await call(db,'/api/tasks',{method:'POST',body:{contact:'Inferred date needs context',date_inferred:true}})).status,400);
});

test('editing just context never changes date or status provenance',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({due_date:'2026-11-05'})]));
  const id=(await list(db))[0].id;
  await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{company:'Edited company'}}));
  const flags=db.sqlite.prepare('SELECT due_date_manual,status_manual FROM tasks').get();
  assert.equal(flags.due_date_manual,0); assert.equal(flags.status_manual,0);
  await jsonOk(review(db,[lead({due_date:'2026-11-06'})]));
  assert.equal((await list(db))[0].due_date,'2026-11-06');
});

test('a fresh review without a date/status never rolls overdue tasks forward or reopens a closed task',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({due_date:'2020-01-03',status:'sold',date_inferred:true,timing_note:'Inferred from the stated review schedule.'})]));
  const [before]=await list(db);
  assert.equal(db.sqlite.prepare('SELECT due_date_manual,status_manual FROM tasks').get().due_date_manual,0);
  await jsonOk(review(db,[lead({message:'New context without any new schedule'})]));
  const [after]=await list(db);
  assert.equal(after.due_date,'2020-01-03'); assert.equal(after.status,'sold');
  assert.equal(after.date_inferred,true); assert.equal(after.timing_note,before.timing_note);
});

test('imported source identity is visible but cannot be changed through ordinary edits',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead()])); const [row]=await list(db);
  assert.equal(row.source_key,JSON.stringify(['wingmate','lead-001']));
  for (const body of [{source_record:'another-lead'},{source_system:'Jobber'}]) {
    assert.equal((await call(db,'/api/tasks/'+row.id,{method:'PATCH',body})).status,400);
  }
  assert.equal((await jsonOk(call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{source_record:'lead-001',message:'Ordinary change'}}))).message,'Ordinary change');
});

test('deleting preserves a tombstone and later reviews cannot resurrect that source task',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead()])); const id=(await list(db))[0].id;
  assert.equal((await call(db,'/api/tasks/'+id,{method:'DELETE'})).status,204);
  assert.equal((await list(db)).length,0);
  assert.ok(db.sqlite.prepare('SELECT deleted_at FROM tasks').get().deleted_at);
  assert.deepEqual(await jsonOk(review(db,[lead({message:'Should stay deleted'})])),{created:0,updated:0,skipped_deleted:1,total:1});
  assert.equal((await list(db)).length,0);
  assert.equal((await call(db,'/api/tasks/'+id,{method:'PATCH',body:{status:'open'}})).status,404);
});

test('additive migration preserves legacy calendar rows and protects historical manual dates/status',async t=>{
  const db=setup(t,{migrate:false});
  db.sqlite.prepare("INSERT INTO tasks (user_id,id,legacy_key,contact,company,rep,due_date,source_system,source_record,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)").run('nico-owner','legacy-1','old-local-key','Existing Nico contact','Existing Co','Nico Braswell','2026-12-20','Wingmate','lead-001','done','2026-10-01T00:00:00Z','2026-10-01T00:00:00Z');
  db.sqlite.exec(migration);
  db.sqlite.exec(schedulingMigration);
  assert.deepEqual(await jsonOk(review(db,[lead({due_date:'2026-11-04',status:'open'})])),{created:0,updated:1,skipped_deleted:0,total:1});
  const [row]=await list(db);
  assert.equal(row.id,'legacy-1'); assert.equal(row.legacy_key,'old-local-key');
  assert.equal(row.due_date,'2026-12-20'); assert.equal(row.status,'done');
  assert.equal(row.scheduled,true);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) count FROM tasks').get().count,1);
});

test('legacy duplicate rows are not destructively merged or deleted',async t=>{
  const db=setup(t);
  for (const id of ['old-a','old-b']) db.sqlite.prepare("INSERT INTO tasks (user_id,id,contact,due_date,source_system,source_record,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)").run('nico-owner',id,'Existing task','2026-12-01','Wingmate','lead-001','2026-10-01T00:00:00Z','2026-10-01T00:00:00Z');
  await jsonOk(review(db,[lead()]));
  assert.equal((await list(db)).length,2);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) count FROM tasks WHERE source_key IS NOT NULL').get().count,1);
});

test('Nico ownership rules reject unrelated or unavailable sales records before writing anything',async t=>{
  const db=setup(t);
  const invalid=[
    lead({rep:'Another rep'}),
    lead({source_system:'Jobber'}),
    lead({source_system:'Jobber',owner:'Unavailable',linked_lead:{source_system:'Wingmate',source_record:'lead-confirmed',rep:'Nico'}}),
    lead({source_system:'Jobber',owner:'Other rep'}),
    lead({source_system:'Quo',inbox:'Team inbox'}),
    lead({source_system:'Gmail',owner:'Other rep'}),
    lead({source_system:'PSS Connect'}),
    lead({reply_received:true}),
    lead({source_record:'x'.repeat(201)})
  ];
  for (const item of invalid) assert.equal((await review(db,[item])).status,400,JSON.stringify(item));
  for (const owner of ['--','—','-','null','undefined','unknown owner','owner unavailable']) {
    assert.equal((await review(db,[lead({source_system:'Jobber',owner,linked_lead:{source_system:'Wingmate',source_record:'nico-lead',rep:'Nico'}})])).status,400,owner);
  }
  assert.equal((await list(db)).length,0);
  const good=[
    lead({source_system:'Jobber',source_record:'job-1',owner:'Nico'}),
    lead({source_system:'Jobber',source_record:'job-2',owner:'Another owner',linked_lead:{source_system:'Wingmate',source_record:'lead-confirmed',rep:'Nico Braswell'}}),
    lead({source_system:'Gmail',source_record:'thread-1',owner:'Nico Braswell'}),
    lead({source_system:'PSS Connect',source_record:'connect-1',owner:'Nico'})
  ];
  assert.equal((await jsonOk(review(db,good))).created,4);
});

test('Quo uses only Nico’s inbox and leaves unmatched caller identity unknown',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({source_system:'Quo',source_record:'call-1',inbox:'Nico’s Quo',contact:'Guessed Name',company:'Guessed company',phone:'+13035550123'})]));
  let [row]=await list(db);
  assert.equal(row.contact,'Unidentified caller'); assert.equal(row.company,''); assert.equal(row.phone,'+13035550123');
  await jsonOk(review(db,[lead({source_system:'Quo',source_record:'call-2',inbox:"Nico's Quo",contact:'Matched Name',matched_record:{source_system:'Wingmate',source_record:'lead-1',owner:'Nico Braswell'}})]));
  row=(await list(db)).find(x=>x.source_record==='call-2'); assert.equal(row.contact,'Matched Name');
  const noMatch=lead({source_system:'Quo',source_record:'call-2',inbox:'Nico’s Quo',contact:'Unverified caller'});
  delete noMatch.company;
  await jsonOk(review(db,[noMatch]));
  row=(await list(db)).find(x=>x.source_record==='call-2'); assert.equal(row.contact,'Unidentified caller'); assert.equal(row.company,'');
  await jsonOk(review(db,[lead({source_system:'Quo',source_record:'call-3',inbox:'Nico’s Quo',contact:'Existing saved contact',contact_saved:true})]));
  row=(await list(db)).find(x=>x.source_record==='call-3'); assert.equal(row.contact,'Existing saved contact');
});

test('invalid batch and duplicate source keys do not partially import',async t=>{
  const db=setup(t);
  const response=await review(db,[lead(),lead({source_record:'lead-2',rep:'Other rep'})]);
  assert.equal(response.status,400); assert.equal((await response.json()).details.length,1);
  assert.equal((await list(db)).length,0);
  assert.equal((await review(db,[lead(),lead({source_system:'wingmate'})])).status,400);
  assert.equal((await review(db,Array.from({length:101},(_,i)=>lead({source_record:'lead-'+i})))).status,400);
  assert.equal((await review(db,[])).status,400);
});

test('D1 transaction rolls back valid rows if a later SQL write fails',async t=>{
  const db=setup(t);
  db.sqlite.exec("CREATE TRIGGER simulate_storage_failure BEFORE INSERT ON tasks WHEN NEW.source_record='explode' BEGIN SELECT RAISE(ABORT,'simulated storage failure'); END");
  const response=await review(db,[lead(),lead({source_record:'explode'})]);
  assert.equal(response.status,500);
  assert.equal((await list(db)).length,0);
});

test('unapplied migrations report a concrete blocker without revealing SQL or replacing storage',async t=>{
  const db=setup(t,{migrate:false});
  const response=await call(db,'/api/tasks'); assert.equal(response.status,503);
  assert.match((await response.json()).error,/0001_review_imports/);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) count FROM tasks').get().count,0);
  assert.equal((await call(null,'/api/tasks')).status,503);
});

test('the scheduling migration keeps all existing assignments, dates, statuses and identities intact',async t=>{
  const db=setup(t,{migrate:false}); db.sqlite.exec(migration);
  for (const [id,date,status] of [['existing-open','2020-01-02','open'],['existing-done','2026-12-01','done'],['existing-sold','2027-02-03','sold']]) {
    db.sqlite.prepare('INSERT INTO tasks (user_id,id,contact,due_date,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)').run('nico-owner',id,id,date,status,'2020-01-01T00:00:00Z','2020-01-01T00:00:00Z');
  }
  const before=db.sqlite.prepare('SELECT id,due_date,status FROM tasks ORDER BY id').all();
  db.sqlite.exec(schedulingMigration);
  const after=await list(db);
  assert.deepEqual(after.map(({id,due_date,status})=>({id,due_date,status})).sort((a,b)=>a.id.localeCompare(b.id)),before.map(x=>({...x})));
  assert.ok(after.every(row=>row.scheduled===true));
  assert.throws(()=>db.sqlite.prepare('UPDATE tasks SET scheduled=2').run(),/CHECK constraint/);
});

test('new review recommendations become suggestions despite a supplied assignment flag',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead({scheduled:true,due_date:'2020-01-02'}),lead({source_record:'lead-002',scheduled:false})]));
  const rows=await list(db);
  assert.equal(rows.length,2); assert.ok(rows.every(row=>row.scheduled===false));
  assert.equal(rows.find(row=>row.source_record==='lead-001').due_date,'2020-01-02');
  const defaulted=rows.find(row=>row.source_record==='lead-002');
  assert.equal(defaulted.due_date,localDate()); assert.equal(defaulted.date_inferred,true);
  assert.match(defaulted.timing_note,/default/);
});

test('manual calendar tasks default assigned while new suggestions can omit a proposed date',async t=>{
  const db=setup(t);
  assert.equal((await create(db,{contact:'Calendar task'})).scheduled,true);
  const suggestion=await create(db,{contact:'Suggestion',scheduled:false});
  assert.equal(suggestion.scheduled,false); assert.equal(suggestion.due_date,localDate());
  assert.equal(suggestion.date_inferred,true); assert.match(suggestion.timing_note,/Proposed.*default/);
  const explicit=await create(db,{contact:'Proposed for later',scheduled:false,due_date:'2027-04-15'});
  assert.equal(explicit.scheduled,false); assert.equal(explicit.due_date,'2027-04-15');
});

test('assigning, rescheduling, and unassigning survive repeated review imports',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead()])); const id=(await list(db))[0].id;
  let row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-11',scheduled:true}}));
  assert.equal(row.scheduled,true); assert.equal(row.due_date,'2026-12-11');
  row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-12'}}));
  assert.equal(row.scheduled,true); assert.equal(row.due_date,'2026-12-12');
  await jsonOk(review(db,[lead({scheduled:false,due_date:'2026-11-01',message:'Refreshed details'})]));
  [row]=await list(db); assert.equal(row.scheduled,true); assert.equal(row.due_date,'2026-12-12'); assert.equal(row.message,'Refreshed details');
  row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{scheduled:false}}));
  assert.equal(row.scheduled,false); assert.equal(row.due_date,'2026-12-12');
  await jsonOk(review(db,[lead({scheduled:true,due_date:'2026-11-02'})]));
  [row]=await list(db); assert.equal(row.scheduled,false); assert.equal(row.due_date,'2026-12-12');
});

test('editing a suggested date can stay unassigned; assignment requires an explicit valid day',async t=>{
  const db=setup(t);
  const row=await create(db,{contact:'Unassigned',scheduled:false});
  assert.equal((await call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{scheduled:true}})).status,400);
  assert.equal((await call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{scheduled:true,due_date:'2026-02-30'}})).status,400);
  let saved=await jsonOk(call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{due_date:'2026-12-15',scheduled:false}}));
  assert.equal(saved.scheduled,false); assert.equal(saved.due_date,'2026-12-15');
  saved=await jsonOk(call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{due_date:'2026-12-16'}}));
  assert.equal(saved.scheduled,true); assert.equal(saved.due_date,'2026-12-16');
});

test('scheduling accepts only booleans and cannot be changed by another owner',async t=>{
  const db=setup(t);
  const row=await create(db,{contact:'Private suggestion',scheduled:false});
  for (const scheduled of ['true',1,0,null,'false']) {
    assert.equal((await call(db,'/api/tasks',{method:'POST',body:{contact:'Invalid scheduling',scheduled}})).status,400);
    assert.equal((await call(db,'/api/tasks/'+row.id,{method:'PATCH',body:{scheduled,due_date:'2026-12-17'}})).status,400);
    assert.equal((await review(db,[lead({scheduled})])).status,400);
  }
  assert.equal((await call(db,'/api/tasks/'+row.id,{method:'PATCH',owner:'other-owner',body:{scheduled:true,due_date:'2026-12-17'}})).status,404);
  const [saved]=await list(db); assert.equal(saved.scheduled,false);
});

test('closed and reopened tasks retain their independent suggestion or calendar assignment',async t=>{
  const db=setup(t);
  await jsonOk(review(db,[lead()])); const id=(await list(db))[0].id;
  let row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{status:'done'}}));
  assert.equal(row.status,'done'); assert.equal(row.scheduled,false);
  await jsonOk(review(db,[lead({status:'open',scheduled:true})]));
  [row]=await list(db); assert.equal(row.status,'done'); assert.equal(row.scheduled,false);
  row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{status:'open'}}));
  assert.equal(row.status,'open'); assert.equal(row.scheduled,false);
  await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{due_date:'2026-12-18',scheduled:true,status:'sold'}}));
  row=await jsonOk(call(db,'/api/tasks/'+id,{method:'PATCH',body:{status:'open'}}));
  assert.equal(row.scheduled,true); assert.equal(row.due_date,'2026-12-18');
});

test('an existing review-import database without the scheduling migration reports the missing prerequisite',async t=>{
  const db=setup(t,{migrate:false}); db.sqlite.exec(migration);
  const response=await call(db,'/api/tasks'); assert.equal(response.status,503);
  assert.match((await response.json()).error,/0002_task_scheduling/);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) count FROM tasks').get().count,0);
});
