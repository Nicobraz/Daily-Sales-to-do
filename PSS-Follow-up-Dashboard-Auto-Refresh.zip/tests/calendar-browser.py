"""Local-only browser smoke tests. Requires Python Playwright and Chromium.

Run from the repository with: python3 tests/calendar-browser.py
The script starts its own loopback server with a temporary synthetic SQLite DB.
It never reads production D1 or contacts any sales system.
"""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import urllib.request
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from playwright.sync_api import sync_playwright, expect


ROOT = Path(__file__).resolve().parents[1]
PORT = int(os.environ.get("PSS_BROWSER_TEST_PORT", "8790"))
BASE = f"http://127.0.0.1:{PORT}"
TODAY = datetime.now(ZoneInfo("America/Denver")).date()
WEEK = TODAY - timedelta(days=TODAY.weekday())
PASSED = []


def record(message):
    PASSED.append(message)
    print(f"PASS {message}", flush=True)


def request(page, method, path, body=None):
    response = page.request.fetch(BASE + path, method=method, data=body)
    assert response.ok, f"{method} {path}: {response.status} {response.text()}"
    return response.json() if response.status != 204 else None


def tasks(page):
    return request(page, "GET", "/api/tasks")


def ready(page):
    expect(page.locator("#summary")).to_contain_text("Dates use Mountain Time")
    expect(page.locator("#add")).to_be_enabled()


def shown_card(page, task_id, area="#calendar"):
    return page.locator(f'{area} .task[data-task-id="{task_id}"]').first


def wait_action(page, action, method, path):
    with page.expect_response(lambda r: r.request.method == method and r.url.endswith(path)) as result:
        action()
    response = result.value
    assert response.ok, f"{method} {path}: {response.status} {response.text()}"
    expect(page.locator("#add")).to_be_enabled()
    return response.json() if response.status != 204 else None


def import_review(page, payload, accepted=True):
    page.locator("#import").click()
    expect(page.locator("#import-overlay")).to_have_class("overlay open")
    page.locator("#import-json").fill(json.dumps(payload))
    page.locator("#preview-import").click()
    expect(page.locator("#import-preview")).to_contain_text(f'{len(payload["tasks"])} tasks to import')
    with page.expect_response(lambda r: r.request.method == "POST" and r.url.endswith("/api/import-review")) as result:
        page.locator("#confirm-import").click()
    response = result.value
    expect(page.locator("#add")).to_be_enabled()
    if accepted:
        assert response.ok, response.text()
        expect(page.locator("#import-overlay")).not_to_have_class("overlay open")
    else:
        assert response.status == 400, response.text()
        expect(page.locator("#import-error")).to_be_visible()
        expect(page.locator("#import-error")).to_contain_text("Nothing was imported")
        page.locator('[data-close="import-overlay"]').click()
    return response.json()


def run(browser):
    errors = []
    desktop = browser.new_context(viewport={"width": 1440, "height": 1050})
    page = desktop.new_page()
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.goto(BASE)
    ready(page)
    assert len(tasks(page)) == 0

    # Add from a different displayed week: the global Add action still means today.
    page.locator("#next").click()
    page.locator("#add").click()
    form = page.locator("#task-form")
    expect(form.locator('[name="due_date"]')).to_have_value(TODAY.isoformat())
    supplied = {
        "contact": "Synthetic Browser Prospect",
        "company": "Synthetic Example Company",
        "rep": "Nico Braswell",
        "last_interaction_date": (TODAY - timedelta(days=2)).isoformat(),
        "why": "Synthetic quote request",
        "next_action": "Review the synthetic estimate",
        "message": "Synthetic suggested message; do not send.",
        "source_system": "Personal",
        "source_record": "browser-manual-1",
        "url": "https://example.com/synthetic-record",
        "extra_url": "https://example.com/synthetic-related",
        "phone": "+13035550123",
    }
    for name, value in supplied.items():
        form.locator(f'[name="{name}"]').fill(value)
    row = wait_action(page, lambda: form.get_by_role("button", name="Save task", exact=True).click(), "POST", "/api/tasks")
    task_id = row["id"]
    page.locator("#today").click()
    card = shown_card(page, task_id)
    expect(card).to_contain_text("Synthetic Browser Prospect")
    expect(card).to_contain_text("Nico Braswell")
    expect(card).to_contain_text("Last interaction:")
    expect(card.locator('a[href="https://example.com/synthetic-record"]')).to_have_count(1)
    expect(card.locator('a[href="https://example.com/synthetic-related"]')).to_have_count(1)
    saved = next(t for t in tasks(page) if t["id"] == task_id)
    for key, value in supplied.items():
        assert saved[key] == value, key
    record("desktop create defaults to today and preserves full source/context fields")

    card.locator('[data-action="edit"]').click()
    form.locator('[name="company"]').fill("Synthetic Edited Company")
    wait_action(page, lambda: form.get_by_role("button", name="Save task", exact=True).click(), "PATCH", "/api/tasks/" + task_id)
    expect(shown_card(page, task_id)).to_contain_text("Synthetic Edited Company")
    assert next(t for t in tasks(page) if t["id"] == task_id)["last_interaction_date"] == supplied["last_interaction_date"]
    record("partial edit persists and retains interaction dates and links")

    move_date = WEEK + timedelta(days=1 if TODAY != WEEK + timedelta(days=1) else 2)
    shown_card(page, task_id).locator('[data-action="move"]').click()
    page.locator('#move-form [name="due_date"]').fill(move_date.isoformat())
    wait_action(page, lambda: page.locator("#move-form").get_by_role("button", name="Move task", exact=True).click(), "PATCH", "/api/tasks/" + task_id)
    expect(page.locator(f'#calendar [data-day="{move_date.isoformat()}"] .task[data-task-id="{task_id}"]')).to_have_count(1)
    drag_date = WEEK + timedelta(days=4 if move_date != WEEK + timedelta(days=4) else 5)
    source = shown_card(page, task_id)
    target = page.locator(f'#calendar .day[data-day="{drag_date.isoformat()}"] .day-head')
    wait_action(page, lambda: source.drag_to(target), "PATCH", "/api/tasks/" + task_id)
    assert next(t for t in tasks(page) if t["id"] == task_id)["due_date"] == drag_date.isoformat()
    expect(page.locator(f'#calendar [data-day="{drag_date.isoformat()}"] .task[data-task-id="{task_id}"]')).to_have_count(1)
    record("date picker and actual desktop drag/drop move the saved task")

    status_rows = []
    for status in ("done", "sold", "not_happening"):
        status_rows.append(request(page, "POST", "/api/tasks", {"contact": "Synthetic status " + status, "due_date": TODAY.isoformat()}))
    historic = request(page, "POST", "/api/tasks", {"contact": "Synthetic historical closed", "due_date": (TODAY - timedelta(days=45)).isoformat()})
    request(page, "PATCH", "/api/tasks/" + historic["id"], {"status": "done"})
    overdue = request(page, "POST", "/api/tasks", {"contact": "Synthetic old overdue", "due_date": (TODAY - timedelta(days=18)).isoformat()})
    page.reload()
    ready(page)
    for status, row in zip(("done", "sold", "not_happening"), status_rows):
        button = shown_card(page, row["id"]).locator(f'[data-action="status"][data-value="{status}"]')
        wait_action(page, lambda b=button: b.click(), "PATCH", "/api/tasks/" + row["id"])
        expect(shown_card(page, row["id"])).to_have_count(0)
    page.locator("#closed").click()
    expect(page.locator("#closed-view")).to_be_visible()
    expect(page.locator("#calendar")).to_be_hidden()
    for row in [*status_rows, historic]:
        expect(shown_card(page, row["id"], "#closed-view")).to_be_visible()
    expect(shown_card(page, overdue["id"], "#closed-view")).to_have_count(0)
    page.locator("#closed").click()
    record("Done/Sold/Not happening leave active view; closed view includes every historical date")

    review = {"tasks": [{"source_system": "Wingmate", "source_record": "synthetic-browser-review", "rep": "Nico Braswell", "contact": "Synthetic imported prospect", "message": "Synthetic first recommendation"}]}
    result = import_review(page, review)
    assert result["created"] == 1
    imported = next(t for t in tasks(page) if t["source_record"] == "synthetic-browser-review")
    assert imported["due_date"] == TODAY.isoformat()
    assert imported["date_inferred"] is True
    assert imported["scheduled"] is False
    expect(shown_card(page, imported["id"], "#suggestions-panel")).to_be_visible()
    expect(shown_card(page, imported["id"])).to_have_count(0)
    expect(shown_card(page, imported["id"], "#overdue-panel")).to_have_count(0)
    shown_card(page, imported["id"], "#suggestions-panel").locator('[data-action="edit"]').click()
    expect(form.locator('[name="source_record"]')).to_have_attribute("readonly", "")
    page.locator('[data-close="task-overlay"]').click()
    wait_action(page, lambda: shown_card(page, imported["id"], "#suggestions-panel").locator('[data-action="assign-today"]').click(), "PATCH", "/api/tasks/" + imported["id"])
    saved = next(t for t in tasks(page) if t["id"] == imported["id"])
    assert saved["scheduled"] is True and saved["due_date"] == TODAY.isoformat()
    expect(shown_card(page, imported["id"])).to_be_visible()
    expect(shown_card(page, imported["id"], "#suggestions-panel")).to_have_count(0)
    record("new review tasks stay suggested until Today explicitly assigns the calendar date")
    shown_card(page, imported["id"]).locator('[data-action="move"]').click()
    manually_moved = (TODAY + timedelta(days=15)).isoformat()
    page.locator('#move-form [name="due_date"]').fill(manually_moved)
    wait_action(page, lambda: page.locator("#move-form").get_by_role("button", name="Move task", exact=True).click(), "PATCH", "/api/tasks/" + imported["id"])
    # The API models another device marking the task sold; the first device then imports a review.
    request(page, "PATCH", "/api/tasks/" + imported["id"], {"status": "sold"})
    review["tasks"][0].update({"due_date": TODAY.isoformat(), "status": "open", "message": "Synthetic updated recommendation"})
    result = import_review(page, review)
    assert result["created"] == 0 and result["updated"] == 1
    saved = next(t for t in tasks(page) if t["id"] == imported["id"])
    assert saved["due_date"] == manually_moved and saved["status"] == "sold"
    assert saved["scheduled"] is True
    assert saved["message"] == "Synthetic updated recommendation"
    assert len([t for t in tasks(page) if t["source_record"] == "synthetic-browser-review"]) == 1
    record("owner-session JSON import previews and updates one task without resetting manual date/status")

    # An owner-chosen schedule can still have an explicitly inferred timing label.
    # The label and explanation must survive date edits independently of import protection.
    page.locator("#closed").click()
    shown_card(page, imported["id"], "#closed-view").locator('[data-action="edit"]').click()
    inferred_date = (TODAY + timedelta(days=20)).isoformat()
    inference_note = "Synthetic inferred timing; no customer commitment recorded."
    form.locator('[name="due_date"]').fill(inferred_date)
    form.locator('[name="date_inferred"]').check()
    form.locator('[name="timing_note"]').fill(inference_note)
    wait_action(page, lambda: form.get_by_role("button", name="Save task", exact=True).click(), "PATCH", "/api/tasks/" + imported["id"])
    expect(shown_card(page, imported["id"], "#closed-view")).to_contain_text("Inferred timing")
    expect(shown_card(page, imported["id"], "#closed-view")).to_contain_text(inference_note)
    page.reload()
    ready(page)
    saved = next(t for t in tasks(page) if t["id"] == imported["id"])
    assert saved["due_date"] == inferred_date and saved["date_inferred"] is True
    assert saved["timing_note"] == inference_note
    import_review(page, review)
    saved = next(t for t in tasks(page) if t["id"] == imported["id"])
    assert saved["due_date"] == inferred_date and saved["status"] == "sold"
    assert saved["date_inferred"] is True and saved["timing_note"] == inference_note
    record("editing a due date retains explicit inferred timing through reload and reimport")

    suggestion_batch = {"tasks": [
        {"source_system": "Wingmate", "source_record": "synthetic-suggest-old", "rep": "Nico Braswell", "contact": "Synthetic pending old suggestion", "due_date": (TODAY - timedelta(days=9)).isoformat()},
        {"source_system": "Wingmate", "source_record": "synthetic-suggest-date", "rep": "Nico Braswell", "contact": "Synthetic choose-day suggestion", "due_date": (TODAY + timedelta(days=40)).isoformat()},
        {"source_system": "Wingmate", "source_record": "synthetic-suggest-drag", "rep": "Nico Braswell", "contact": "Synthetic drag suggestion", "due_date": (TODAY - timedelta(days=35)).isoformat(), "scheduled": True},
        {"source_system": "Wingmate", "source_record": "synthetic-suggest-closed", "rep": "Nico Braswell", "contact": "Synthetic closable suggestion", "due_date": (TODAY - timedelta(days=50)).isoformat()},
    ]}
    assert import_review(page, suggestion_batch)["created"] == 4
    suggestions = {t["source_record"]: t for t in tasks(page) if t["source_record"].startswith("synthetic-suggest-")}
    for suggestion in suggestions.values():
        assert suggestion["scheduled"] is False
        expect(shown_card(page, suggestion["id"], "#suggestions-panel")).to_be_visible()
        expect(shown_card(page, suggestion["id"])).to_have_count(0)
        expect(shown_card(page, suggestion["id"], "#overdue-panel")).to_have_count(0)
    record("suggested tasks with past proposed dates never enter calendar or overdue, even when an import requests scheduling")

    choose = suggestions["synthetic-suggest-date"]
    chosen_date = (WEEK + timedelta(days=2)).isoformat()
    shown_card(page, choose["id"], "#suggestions-panel").locator('[data-action="move"]').click()
    page.locator('#move-form [name="due_date"]').fill(chosen_date)
    wait_action(page, lambda: page.locator("#save-move").click(), "PATCH", "/api/tasks/" + choose["id"])
    saved = next(t for t in tasks(page) if t["id"] == choose["id"])
    assert saved["scheduled"] is True and saved["due_date"] == chosen_date
    expect(shown_card(page, choose["id"])).to_be_visible()
    wait_action(page, lambda: shown_card(page, choose["id"]).locator('[data-action="unschedule"]').click(), "PATCH", "/api/tasks/" + choose["id"])
    page.reload()
    ready(page)
    saved = next(t for t in tasks(page) if t["id"] == choose["id"])
    assert saved["scheduled"] is False and saved["due_date"] == chosen_date
    expect(shown_card(page, choose["id"], "#suggestions-panel")).to_be_visible()
    expect(shown_card(page, choose["id"])).to_have_count(0)
    record("choosing a date assigns a suggestion; Back to suggestions persists without losing its chosen date")

    drag = suggestions["synthetic-suggest-drag"]
    suggestion_drag_date = (WEEK + timedelta(days=4)).isoformat()
    wait_action(page, lambda: shown_card(page, drag["id"], "#suggestions-panel").drag_to(page.locator(f'#calendar .day[data-day="{suggestion_drag_date}"] .day-head')), "PATCH", "/api/tasks/" + drag["id"])
    expect(shown_card(page, drag["id"])).to_be_visible()
    for task in suggestion_batch["tasks"]:
        task["due_date"] = (TODAY + timedelta(days=85)).isoformat()
        task["status"] = "open"
    assert import_review(page, suggestion_batch)["updated"] == 4
    saved_by_id = {t["id"]: t for t in tasks(page)}
    assert saved_by_id[drag["id"]]["scheduled"] is True
    assert saved_by_id[drag["id"]]["due_date"] == suggestion_drag_date
    assert saved_by_id[choose["id"]]["scheduled"] is False
    assert saved_by_id[choose["id"]]["due_date"] == chosen_date
    assert len([t for t in tasks(page) if t["source_record"].startswith("synthetic-suggest-")]) == 4
    record("native dragging assigns a suggestion and reimports preserve both assigned and returned-to-inbox choices")

    closable = suggestions["synthetic-suggest-closed"]
    wait_action(page, lambda: shown_card(page, closable["id"], "#suggestions-panel").locator('[data-action="status"][data-value="done"]').click(), "PATCH", "/api/tasks/" + closable["id"])
    import_review(page, {"tasks": [suggestion_batch["tasks"][3]]})
    closed_suggestion = next(t for t in tasks(page) if t["id"] == closable["id"])
    assert closed_suggestion["status"] == "done" and closed_suggestion["scheduled"] is False
    expect(shown_card(page, closable["id"], "#suggestions-panel")).to_have_count(0)
    page.locator("#closed").click()
    expect(shown_card(page, closable["id"], "#closed-view")).to_be_visible()
    wait_action(page, lambda: shown_card(page, closable["id"], "#closed-view").locator('[data-action="status"][data-value="open"]').click(), "PATCH", "/api/tasks/" + closable["id"])
    page.locator("#closed").click()
    expect(shown_card(page, closable["id"], "#suggestions-panel")).to_be_visible()
    expect(shown_card(page, closable["id"])).to_have_count(0)
    assert next(t for t in tasks(page) if t["id"] == closable["id"])["scheduled"] is False
    record("closing a suggestion survives reimport, and reopening returns it to Suggested without scheduling it")

    before = len(tasks(page))
    bad = {"tasks": [{"source_system": "Wingmate", "source_record": "synthetic-other-rep", "rep": "Another rep", "contact": "Must not import"}]}
    import_review(page, bad, accepted=False)
    assert len(tasks(page)) == before
    expect(page.locator("#notice.error")).to_have_count(0)
    record("invalid ownership is rejected visibly and writes no tasks")

    payload = '<img src=x onerror="window.__xss=1">'
    xss = request(page, "POST", "/api/tasks", {"contact": payload})
    page.reload()
    ready(page)
    expect(shown_card(page, xss["id"]).locator("h3")).to_have_text(payload)
    expect(shown_card(page, xss["id"]).locator("img")).to_have_count(0)
    assert page.evaluate("window.__xss || null") is None
    assert page.evaluate("localStorage.length") == 0
    record("task text is escaped and browser localStorage stays empty")

    page.once("dialog", lambda dialog: dialog.accept())
    wait_action(page, lambda: shown_card(page, xss["id"]).locator('[data-action="delete"]').click(), "DELETE", "/api/tasks/" + xss["id"])
    page.reload()
    ready(page)
    assert not any(t["id"] == xss["id"] for t in tasks(page))
    expect(shown_card(page, xss["id"])).to_have_count(0)
    record("Delete removes the task persistently across reload")

    mobile = browser.new_context(viewport={"width": 375, "height": 812}, is_mobile=True, has_touch=True, device_scale_factor=1)
    phone = mobile.new_page()
    phone.on("pageerror", lambda error: errors.append(str(error)))
    phone.goto(BASE)
    ready(phone)
    tabs = phone.locator("#day-tabs .day-tab")
    expect(tabs).to_have_count(7)
    for index in range(7):
        tab = phone.locator("#day-tabs .day-tab").nth(index)
        day = tab.get_attribute("data-day-select")
        tab.click()
        expect(phone.locator(f'#day-tabs [data-day-select="{day}"]')).to_have_attribute("aria-pressed", "true")
        expect(phone.locator(f'#calendar .day[data-day="{day}"]')).to_be_visible()
        expect(phone.locator("#calendar .day:visible")).to_have_count(1)
    phone.locator("#prev").click()
    expect(phone.locator("#day-tabs .day-tab").first).to_have_attribute("data-day-select", (WEEK - timedelta(days=7)).isoformat())
    phone.locator("#next").click()
    phone.locator("#today").click()
    expect(phone.locator(f'#day-tabs [data-day-select="{TODAY.isoformat()}"]')).to_have_attribute("aria-pressed", "true")
    expect(phone.locator("#overdue-panel")).to_be_visible()
    expect(shown_card(phone, overdue["id"], "#overdue-panel")).to_be_visible()
    expect(shown_card(phone, overdue["id"], "#overdue-panel")).to_contain_text("Overdue")
    assert phone.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Mobile page overflows horizontally"
    assert phone.evaluate("localStorage.length") == 0
    assert next(t for t in tasks(phone) if t["id"] == task_id)["company"] == "Synthetic Edited Company"
    record("mobile can select all seven days, navigate weeks, see overdue tasks and share saved data without overflow")

    expect(phone.locator("#suggestions-panel")).to_be_visible()
    expect(shown_card(phone, choose["id"], "#suggestions-panel")).to_be_visible()
    expect(shown_card(phone, closable["id"], "#suggestions-panel")).to_be_visible()
    mobile_suggestion = suggestions["synthetic-suggest-old"]
    expect(shown_card(phone, mobile_suggestion["id"], "#suggestions-panel")).to_be_visible()
    shown_card(phone, mobile_suggestion["id"], "#suggestions-panel").locator('[data-action="move"]').click()
    phone.locator('#move-form [name="due_date"]').fill(TODAY.isoformat())
    wait_action(phone, lambda: phone.locator("#save-move").click(), "PATCH", "/api/tasks/" + mobile_suggestion["id"])
    expect(shown_card(phone, mobile_suggestion["id"])).to_be_visible()
    page.reload()
    ready(page)
    assigned = next(t for t in tasks(page) if t["id"] == mobile_suggestion["id"])
    assert assigned["scheduled"] is True and assigned["due_date"] == TODAY.isoformat()
    assert phone.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Mobile suggestions overflow horizontally"
    record("mobile Suggested inbox is visible and choosing a day persists assignment across devices")

    shown_card(phone, overdue["id"], "#overdue-panel").locator('[data-action="move"]').click()
    phone.locator('#move-form [name="due_date"]').fill(TODAY.isoformat())
    wait_action(phone, lambda: phone.locator("#move-form").get_by_role("button", name="Move task", exact=True).click(), "PATCH", "/api/tasks/" + overdue["id"])
    expect(shown_card(phone, overdue["id"])).to_be_visible()
    page.reload()
    ready(page)
    assert next(t for t in tasks(page) if t["id"] == overdue["id"])["due_date"] == TODAY.isoformat()
    record("touch-device date move persists and appears in the separate desktop session")

    # Simulate an authenticated external producer writing a review while this
    # dashboard remains open. Virtual time makes the polling check deterministic.
    automatic = browser.new_context(viewport={"width": 1440, "height": 1050})
    live = automatic.new_page()
    live.on("pageerror", lambda error: errors.append(str(error)))
    live.clock.install()
    live.goto(BASE)
    live.bring_to_front()
    ready(live)
    document_id = live.evaluate("window.__testDocumentId = crypto.randomUUID()")
    delivery = {"tasks": [{"source_system": "Wingmate", "source_record": "synthetic-external-review", "rep": "Nico Braswell", "contact": "Synthetic externally delivered suggestion"}]}
    assert request(page, "POST", "/api/import-review", delivery)["created"] == 1
    delivered = next(t for t in tasks(page) if t["source_record"] == "synthetic-external-review")
    expect(shown_card(live, delivered["id"], "#suggestions-panel")).to_have_count(0)
    with live.expect_response(lambda response: response.request.method == "GET" and response.url.endswith("/api/tasks")):
        live.clock.run_for(30_001)
    expect(shown_card(live, delivered["id"], "#suggestions-panel")).to_be_visible()
    assert live.evaluate("window.__testDocumentId") == document_id
    assert delivered["scheduled"] is False
    expect(shown_card(live, delivered["id"])).to_have_count(0)
    record("an externally stored owner review suggestion automatically appears in the open dashboard without reload or manual import")

    live.locator("#add").click()
    draft = live.locator('#task-form [name="contact"]')
    draft.fill("Synthetic unsaved edit draft")
    reads = []
    live.on("request", lambda req: reads.append(req.url) if req.method == "GET" and req.url.endswith("/api/tasks") else None)
    reads_before = len(reads)
    delivery["tasks"][0].update({"source_record": "synthetic-external-review-during-draft", "contact": "Synthetic delivery during draft"})
    assert request(page, "POST", "/api/import-review", delivery)["created"] == 1
    waiting = next(t for t in tasks(page) if t["source_record"] == "synthetic-external-review-during-draft")
    live.clock.run_for(30_000)
    expect(live.locator("#task-overlay")).to_have_class("overlay open")
    expect(draft).to_have_value("Synthetic unsaved edit draft")
    expect(shown_card(live, waiting["id"], "#suggestions-panel")).to_have_count(0)
    assert len(reads) == reads_before, "Auto-refresh fetched while an edit draft was open"
    live.locator('[data-close="task-overlay"]').click()
    with live.expect_response(lambda response: response.request.method == "GET" and response.url.endswith("/api/tasks")):
        live.evaluate("window.dispatchEvent(new Event('focus'))")
    expect(shown_card(live, waiting["id"], "#suggestions-panel")).to_be_visible()
    assert live.evaluate("window.__testDocumentId") == document_id
    record("auto-refresh pauses during active drafts and resumes on focus after the draft closes")
    automatic.close()

    output = ROOT / "test-results"
    output.mkdir(exist_ok=True)
    page.screenshot(path=str(output / "calendar-desktop.png"), full_page=True)
    phone.screenshot(path=str(output / "calendar-mobile.png"), full_page=True)
    assert not errors, "Browser JavaScript errors: " + repr(errors)
    record("desktop/mobile browsers report no uncaught JavaScript errors")
    mobile.close()
    desktop.close()


def main():
    local = ROOT / ".local"
    local.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="browser-", dir=local) as temp:
        env = dict(os.environ, PSS_LOCAL_DB=str(Path(temp) / "calendar.sqlite"), PSS_LOCAL_PORT=str(PORT))
        log_path = Path(temp) / "server.log"
        with log_path.open("w+") as log:
            server = subprocess.Popen(["node", "scripts/dev-server.mjs"], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            try:
                for attempt in range(100):
                    if server.poll() is not None:
                        log.seek(0)
                        raise RuntimeError("Local server failed: " + log.read())
                    try:
                        with urllib.request.urlopen(BASE + "/api/tasks", timeout=1) as response:
                            if response.status == 200:
                                break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError("Local server did not become ready")
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(executable_path="/usr/bin/chromium", headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
                    try:
                        run(browser)
                    finally:
                        browser.close()
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()
    print(f"{len(PASSED)} browser checks passed; synthetic local database removed.", flush=True)


if __name__ == "__main__":
    main()
