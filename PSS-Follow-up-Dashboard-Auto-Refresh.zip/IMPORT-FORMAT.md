# Daily review batch format

In the signed-in private calendar, choose **Import review** and paste or upload a
JSON document. This imports dashboard tasks only and never sends messages.
New records appear in **Suggested tasks**. Nico chooses **Today** or **Assign day**
to put them on the calendar. Reimporting a record never changes whether it is
assigned or suggested.

```json
{
  "tasks": [
    {
      "source_system": "Wingmate",
      "source_record": "stable-record-id-from-the-review",
      "contact": "Contact from the verified source",
      "company": "Company from the verified source",
      "rep": "Nico Braswell",
      "last_interaction_date": "",
      "priority": "Medium",
      "why": "Reason supported by the reviewed records",
      "next_action": "Recommended follow-up action",
      "message": "Suggested message for Nico to review",
      "url": "https://example.com/source-record"
    }
  ]
}
```

The example is a format illustration, not a customer record; do not import it as
real sales data. Batches contain at most 100 tasks. All records in a batch must be
valid; a rejected batch writes no task changes. Links must use HTTPS, phone
numbers must use international `+` format, and dates must be real calendar dates
written as `YYYY-MM-DD`. Unknown last interaction dates stay empty.

`source_system` and `source_record` identify one follow-up for that record. Use
the actual stable source ID, never a task's text, the review date, an array index,
or a random ID. The same source record in later reviews updates the existing task.
For records appearing in multiple systems, the review must choose a canonical
source identity and include the other link in `extra_url`; the importer cannot
discover cross-system duplicates without source access.

Optional task fields are `due_date`, `priority`, `why`, `next_action`, `message`,
`url`, `extra_url`, `phone`, `last_interaction_date`, `date_inferred`, and
`timing_note`. Optional `status` is one of `open`, `done`, `sold`, or
`not_happening`; omit it to keep an existing status. `reply_received: true`
rejects a follow-up that needs a fresh review of the latest interaction.
Supported priorities are Urgent, High, Medium, Opportunity, and Low.
When a review provides a date, use it. When no date is provided, omit `due_date`:
new suggestions receive today in America/Denver as default/inferred proposed timing;
existing tasks keep their date so overdue follow-ups are not silently postponed.
An unassigned suggestion has no active calendar deadline and never counts as overdue.
Use `date_inferred: true` with a clear `timing_note` for any other inferred date.
Do not infer interactions, promises, or last-interaction dates.

## Ownership supplied by the review

- **Wingmate:** `rep` must explicitly be `Nico` or `Nico Braswell`.
- **Jobber:** provide the nonempty `owner` from the source. Include it only if
  the owner is Nico, or `linked_lead` identifies a confirmed Nico-assigned
  Wingmate lead: `{ "source_system": "Wingmate", "source_record": "lead-id",
  "rep": "Nico Braswell" }`. Records with unavailable ownership are excluded.
- **Quo:** `inbox` must be `Nico’s Quo` (straight apostrophe also accepted). To
  use an already-saved contact, include `contact_saved: true`. To identify an
  unsaved caller, supply `matched_record` only after confirming the
  number against Nico-owned Wingmate/Jobber records:
  `{ "source_system": "Wingmate", "source_record": "lead-id",
  "owner": "Nico Braswell" }`. Without a confirmed match, the importer stores
  `Unidentified caller` and clears company information; it does not invent an
  identity. Preserve the actual caller number in `phone` when known.
- **Gmail / PSS Connect:** provide explicit `owner: "Nico Braswell"` from the
  authorized review context.

These are supplied evidence fields, not independently verified connector results.
Before exporting a batch, the daily review must restrict itself to Nico's records,
read only Nico's Quo inbox, cross-check source activity, consolidate duplicates,
and remove follow-ups made obsolete by a reply. Missing access must be reported
by the review rather than filled with guesses.

## Updating an imported task

Imports refresh details without changing dates or statuses Nico has edited.
Imported source IDs stay fixed; edit the contact, message, links, and other details
without changing the record identity. Omitted review details keep their saved
values. Omitted dates/statuses never reset existing tasks.
Legacy tasks have both date and status protected by default. Deleted tasks retain
their source identity as a tombstone so later imports cannot recreate them.
Other owners' tasks are isolated even when they use the same source record ID.

## Scheduling suggestions

`GET /api/tasks` exposes a boolean `scheduled` on each task. `due_date` on an
unassigned suggestion is proposed timing, not a chosen calendar day. Daily review
imports always create new records with `scheduled: false`; an incoming review
cannot bypass the suggestion list or change an existing scheduling choice.

The authenticated owner's actions use the existing task API:

- Add a suggestion: `POST /api/tasks` with `scheduled: false` and task details.
- Add a calendar task: `POST /api/tasks` (defaults `scheduled: true`, due today).
- Assign a day: `PATCH /api/tasks/:id` with
  `{ "due_date": "YYYY-MM-DD", "scheduled": true }`.
- Return to suggestions: `PATCH /api/tasks/:id` with `{ "scheduled": false }`.
- Change only a proposed date: patch `due_date` with `scheduled: false`.

Assigning a previously unassigned task requires an explicit date. For compatibility,
a date-only patch schedules the task; the UI sends explicit scheduling choices.
Reopening a closed suggestion returns it to Suggested tasks, not the calendar.
Scheduling state and completion status are stored independently in D1.

The owner-authenticated routes are `GET /api/tasks`, `POST /api/tasks`,
`PATCH /api/tasks/:id` (partial edit), `PUT /api/tasks/:id` (compatibility edit),
`DELETE /api/tasks/:id`, and `POST /api/import-review`. All require the trusted
Sites identity header set by the hosting platform. Browser mutations use JSON and
the same origin as the Site. The server does not accept an owner ID from JSON.
