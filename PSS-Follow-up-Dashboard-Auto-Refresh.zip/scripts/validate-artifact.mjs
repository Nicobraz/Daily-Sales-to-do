import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const projectRoot = resolve(fileURLToPath(new URL("..", import.meta.url)));
const workerPath = resolve(projectRoot, "dist/server/index.js");
const manifestPath = resolve(projectRoot, "dist/.openai/hosting.json");

const [source, manifest] = await Promise.all([
  readFile(workerPath, "utf8"),
  readFile(manifestPath, "utf8"),
]);
const config = JSON.parse(manifest);
assert.equal(config.project_id, "appgprj_6aea78eba9b4819182ed8393975248bb", "Preserve the existing Site project");
assert.equal(config.d1, "DB", "Preserve the existing D1 binding");
assert.equal(config.r2, null);
assert.ok(source.length > 0);

// Import the built entry and its sibling modules using the repository's ESM package.
const workerModule = await import(pathToFileURL(workerPath).href);
assert.equal(
  typeof workerModule.default?.fetch,
  "function",
  `${pathToFileURL(workerPath)} must export default.fetch`,
);

const response = await workerModule.default.fetch(new Request("https://example.test/"), {});
assert.equal(response.status, 401, "Even the calendar page must require authentication");
console.log("Artifact imports successfully, preserves the Site and DB binding, and requires authentication");
