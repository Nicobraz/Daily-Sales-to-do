import { createServer } from "node:http";
import { mkdir, readFile, readdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import worker from "../worker/index.js";
import { openLocalD1 } from "./sqlite-d1.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const path = resolve(root, process.env.PSS_LOCAL_DB || ".local/calendar.sqlite");
await mkdir(dirname(path), { recursive: true });
const db = openLocalD1(path);
db.sqlite.exec("CREATE TABLE IF NOT EXISTS local_migrations (name TEXT PRIMARY KEY)");
for (const name of (await readdir(resolve(root, "drizzle"))).filter(n => n.endsWith(".sql")).sort()) {
  if (db.sqlite.prepare("SELECT name FROM local_migrations WHERE name=?").get(name)) continue;
  const sql = await readFile(resolve(root, "drizzle", name), "utf8");
  db.sqlite.exec("BEGIN");
  try {
    db.sqlite.exec(sql);
    db.sqlite.prepare("INSERT INTO local_migrations (name) VALUES (?)").run(name);
    db.sqlite.exec("COMMIT");
  } catch (error) {
    db.sqlite.exec("ROLLBACK");
    throw error;
  }
}

const port = Number(process.env.PSS_LOCAL_PORT || 8787);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("Invalid PSS_LOCAL_PORT");
const origin = `http://127.0.0.1:${port}`;
const server = createServer(async (incoming, outgoing) => {
  try {
    const chunks = [];
    let size = 0;
    for await (const chunk of incoming) {
      size += chunk.length;
      if (size > 524288) {
        outgoing.writeHead(413).end("Request too large");
        return;
      }
      chunks.push(chunk);
    }
    const headers = new Headers();
    for (const [name, value] of Object.entries(incoming.headers)) {
      if (value) headers.set(name, Array.isArray(value) ? value.join(",") : value);
    }
    // Loopback-only development identity. Never use this harness as a deployed server.
    headers.set("oai-authenticated-user-id", "local-nico");
    const request = new Request(new URL(incoming.url, origin), {
      method: incoming.method,
      headers,
      ...(chunks.length ? { body: Buffer.concat(chunks) } : {}),
    });
    const response = await worker.fetch(request, { DB: db });
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    outgoing.end(Buffer.from(await response.arrayBuffer()));
  } catch (error) {
    console.error(error);
    outgoing.writeHead(500).end("Local development server error");
  }
});
server.listen(port, "127.0.0.1", () => console.log(`Local development server on port ${port}; local SQLite only.`));
for (const signal of ["SIGTERM", "SIGINT"]) {
  process.on(signal, () => server.close(() => { db.close(); process.exit(0); }));
}
