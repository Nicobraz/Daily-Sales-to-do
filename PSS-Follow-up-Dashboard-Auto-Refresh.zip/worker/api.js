const STATUSES = new Set(['open', 'done', 'sold', 'not_happening']);
const PRIORITIES = new Set(['Urgent', 'High', 'Medium', 'Opportunity', 'Low']);
const SOURCES = new Map(['Wingmate', 'Jobber', 'Quo', 'Gmail', 'PSS Connect'].map(s => [s.toLowerCase(), s]));
const TEXT_LIMITS = {contact:160, company:160, rep:100, why:1000, next_action:1000, message:1000, source_system:100, source_record:200, timing_note:1000};
const EDITABLE = [...Object.keys(TEXT_LIMITS), 'due_date', 'last_interaction_date', 'priority', 'url', 'extra_url', 'phone', 'status', 'date_inferred', 'scheduled'];
const INSERT_FIELDS = ['user_id', 'id', 'legacy_key', ...EDITABLE, 'source_key', 'due_date_manual', 'status_manual', 'created_at', 'updated_at'];
const LIST_FIELDS = ['id', 'legacy_key', 'source_key', ...EDITABLE, 'created_at', 'updated_at'];
const OWN = (o,k) => Object.hasOwn(o,k);

class InputError extends Error {
  constructor(message, details = []) { super(message); this.details = details; }
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8', 'cache-control':'private, no-store', 'x-content-type-options':'nosniff'}});
}
export function localDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA',{timeZone:'America/Denver',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date);
  const p = Object.fromEntries(parts.map(v => [v.type,v.value]));
  return p.year+'-'+p.month+'-'+p.day;
}
function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(value+'T12:00:00Z');
  return !Number.isNaN(d.valueOf()) && d.toISOString().slice(0,10) === value;
}
function text(value, name, max) {
  if (typeof value !== 'string') throw new InputError(name+' must be text.');
  const s = value.trim();
  if (s.length > max) throw new InputError(name+' is too long.');
  return s;
}
function httpsUrl(value, name) {
  const s = text(value, name, 1000);
  if (!s) return '';
  let u;
  try { u = new URL(s); } catch { throw new InputError(name+' must be a valid HTTPS URL.'); }
  if (u.protocol !== 'https:' || u.username || u.password) throw new InputError(name+' must be a valid HTTPS URL without embedded credentials.');
  return s;
}
function parseTask(body, previous=null) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new InputError('Task must be an object.');
  const task = previous ? Object.fromEntries(EDITABLE.map(k => [k, previous[k]])) : {
    contact:'',company:'',rep:'Nico Braswell',why:'',next_action:'',message:'',source_system:'Personal',source_record:'',timing_note:'',due_date:localDate(),last_interaction_date:'',priority:'Medium',url:'',extra_url:'',phone:'',status:'open',date_inferred:false,scheduled:true
  };
  for (const [key,max] of Object.entries(TEXT_LIMITS)) if (OWN(body,key)) task[key] = text(body[key],key,max);
  if (!task.contact) throw new InputError('Add a contact or task title.');
  for (const key of ['due_date','last_interaction_date']) if (OWN(body,key)) {
    if (key === 'last_interaction_date' && body[key] === '') task[key] = '';
    else if (!validDate(body[key])) throw new InputError(key+' must be a real calendar date in YYYY-MM-DD format.');
    else task[key] = body[key];
  }
  if (OWN(body,'priority')) {
    if (!PRIORITIES.has(body.priority)) throw new InputError('Choose a supported priority.');
    task.priority = body.priority;
  }
  if (OWN(body,'status')) {
    if (!STATUSES.has(body.status)) throw new InputError('Choose a supported task status.');
    task.status = body.status;
  }
  for (const key of ['url','extra_url']) if (OWN(body,key)) task[key] = httpsUrl(body[key],key);
  if (OWN(body,'phone')) {
    if (body.phone !== '' && (typeof body.phone !== 'string' || !/^\+[0-9]{8,15}$/.test(body.phone))) throw new InputError('phone must use international format, for example +13035550123.');
    task.phone = body.phone;
  }
  if (OWN(body,'date_inferred')) {
    if (typeof body.date_inferred !== 'boolean') throw new InputError('date_inferred must be true or false.');
    task.date_inferred = body.date_inferred;
  }
  task.date_inferred = !!task.date_inferred;
  if (OWN(body,'scheduled')) {
    if (typeof body.scheduled !== 'boolean') throw new InputError('scheduled must be true or false.');
    task.scheduled=body.scheduled;
  }
  task.scheduled=!!task.scheduled;
  if (task.date_inferred && !task.timing_note) throw new InputError('Label inferred timing with timing_note.');
  return task;
}
function isNico(value) { return typeof value === 'string' && ['nico','nico braswell'].includes(value.trim().replace(/\s+/g,' ').toLowerCase()); }
function canonicalSource(value) { return typeof value === 'string' ? SOURCES.get(value.trim().toLowerCase()) : undefined; }
function confirmedLead(value) {
  return value && typeof value === 'object' && canonicalSource(value.source_system) === 'Wingmate' && typeof value.source_record === 'string' && value.source_record.trim() && isNico(value.rep);
}
function confirmedMatch(value) {
  return value && typeof value === 'object' && ['Wingmate','Jobber'].includes(canonicalSource(value.source_system)) && typeof value.source_record === 'string' && value.source_record.trim() && isNico(value.owner);
}
function importTask(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new InputError('Each imported task must be an object.');
  const source = canonicalSource(body.source_system);
  if (!source) throw new InputError('source_system must be Wingmate, Jobber, Quo, Gmail, or PSS Connect.');
  if (typeof body.source_record !== 'string' || !body.source_record.trim()) throw new InputError('A stable source_record ID is required for every import.');
  const data = {...body,source_system:source};
  if (source === 'Wingmate' && !isNico(body.rep)) throw new InputError('Wingmate imports must be explicitly assigned to Nico / Nico Braswell.');
  if (source === 'Jobber') {
    if (typeof body.owner !== 'string' || !body.owner.trim() || ['unknown','unavailable','not available','n/a','none','unassigned','--','—','-','null','undefined','unknown owner','owner unavailable'].includes(body.owner.trim().toLowerCase())) throw new InputError('Jobber records with unavailable ownership cannot be imported.');
    if (!isNico(body.owner) && !confirmedLead(body.linked_lead)) throw new InputError('Jobber imports need Nico ownership or a confirmed Nico-assigned Wingmate linked_lead.');
  }
  if (['Gmail','PSS Connect'].includes(source) && !isNico(body.owner)) throw new InputError(source+' imports require explicit Nico ownership.');
  if (source === 'Quo') {
    if (typeof body.inbox !== 'string' || body.inbox.trim().replaceAll('’',"'") !== "Nico's Quo") throw new InputError('Quo imports may use only the “Nico’s Quo” inbox.');
    if (body.contact_saved !== true && !confirmedMatch(body.matched_record)) {
      data.contact = 'Unidentified caller';
      data.company = '';
    }
  }
  if (body.reply_received === true) throw new InputError('A follow-up cannot be imported after a recorded reply; review the latest interaction first.');
  if (!OWN(body,'due_date')) {
    data.due_date = localDate();
    data.date_inferred = true;
    data.timing_note = 'Proposed for today by default; the review did not specify a date. Choose a day to assign this suggestion.';
  } else if (body.date_inferred === true && (typeof body.timing_note !== 'string' || !body.timing_note.trim())) throw new InputError('Label inferred timing with timing_note.');
  const task = parseTask(data);
  if (!OWN(body,'rep') || !body.rep.trim()) task.rep = 'Nico Braswell';
  // Omitted optional review details do not erase previously supplied context.
  const supplied = new Set([...Object.keys(body),'contact','source_system','source_record','rep']);
  if (source === 'Quo' && body.contact_saved !== true && !confirmedMatch(body.matched_record)) supplied.add('company');
  // Review recommendations enter the owner's inbox. Only a subsequent owner
  // assignment puts them on the calendar; review-supplied flags cannot bypass it.
  return {...task,scheduled:false,source_key:JSON.stringify([source.toLowerCase(),task.source_record]),supplied,due_date_provided:OWN(body,'due_date'),status_provided:OWN(body,'status')};
}
function publicTask(row) {
  return Object.fromEntries(LIST_FIELDS.map(k => [k,['date_inferred','scheduled'].includes(k) ? !!row[k] : row[k]]));
}
async function list(db,user) {
  const rows = await db.prepare('SELECT '+LIST_FIELDS.join(',')+' FROM tasks WHERE user_id=? AND deleted_at IS NULL ORDER BY due_date,created_at,id').bind(user).all();
  return (rows.results || []).map(publicTask);
}
async function find(db,user,id) {
  return db.prepare('SELECT * FROM tasks WHERE user_id=? AND id=? AND deleted_at IS NULL').bind(user,id).first();
}
function insertStatement(db,row,upsert='') {
  return db.prepare('INSERT INTO tasks ('+INSERT_FIELDS.join(',')+') VALUES ('+INSERT_FIELDS.map(() => '?').join(',')+')'+upsert).bind(...INSERT_FIELDS.map(k => typeof row[k] === 'boolean' ? Number(row[k]) : row[k] ?? null));
}
async function readJson(request) {
  if ((request.headers.get('content-type') || '').toLowerCase().split(';')[0].trim() !== 'application/json') throw new InputError('Send JSON with Content-Type: application/json.');
  if (Number(request.headers.get('content-length')) > 500_000) throw new InputError('The JSON batch is too large. Import at most 100 tasks at a time.');
  const reader=request.body?.getReader(),chunks=[];
  let size=0;
  if (reader) while (true) {
    const {value,done}=await reader.read();
    if (done) break;
    size+=value.byteLength;
    if (size>500_000) { await reader.cancel(); throw new InputError('The JSON batch is too large. Import at most 100 tasks at a time.'); }
    chunks.push(value);
  }
  const bytes=new Uint8Array(size);
  let offset=0;
  for (const chunk of chunks) { bytes.set(chunk,offset); offset+=chunk.byteLength; }
  const raw = new TextDecoder().decode(bytes);
  try { return JSON.parse(raw); } catch { throw new InputError('The request body is not valid JSON.'); }
}
async function importReview(db,user,body) {
  if (!body || typeof body !== 'object' || !Array.isArray(body.tasks) || !body.tasks.length || body.tasks.length > 100) throw new InputError('Provide a tasks array with 1–100 tasks.');
  const prepared = [],errors=[],keys=new Set();
  for (let i=0;i<body.tasks.length;i++) {
    try {
      const task = importTask(body.tasks[i]);
      if (keys.has(task.source_key)) throw new InputError('The batch contains a duplicate source_system/source_record.');
      keys.add(task.source_key); prepared.push(task);
    } catch (error) {
      if (!(error instanceof InputError)) throw error;
      errors.push('Task '+(i+1)+': '+error.message);
    }
  }
  if (errors.length) throw new InputError('Nothing was imported. Fix the batch and try again.',errors);
  const now=new Date().toISOString(),statements=[],counts={created:0,updated:0,skipped_deleted:0,total:prepared.length};
  for (const task of prepared) {
    const existing = await db.prepare('SELECT * FROM tasks WHERE user_id=? AND (source_key=? OR (source_key IS NULL AND lower(trim(source_system))=? AND trim(source_record)=?)) ORDER BY CASE WHEN source_key IS NOT NULL THEN 0 ELSE 1 END,created_at,id LIMIT 1').bind(user,task.source_key,task.source_system.toLowerCase(),task.source_record).first();
    if (existing?.deleted_at) counts.skipped_deleted++;
    else if (existing) counts.updated++;
    else counts.created++;
    // Adopt one legacy row without removing or rewriting other historical rows.
    if (existing && !existing.source_key) statements.push(db.prepare('UPDATE tasks SET source_key=? WHERE user_id=? AND id=? AND source_key IS NULL AND NOT EXISTS (SELECT 1 FROM tasks WHERE user_id=? AND source_key=?)').bind(task.source_key,user,existing.id,user,task.source_key));
    const row={...task,user_id:user,id:existing?.id || crypto.randomUUID(),legacy_key:null,due_date_manual:0,status_manual:0,created_at:now,updated_at:now};
    const detailFields = EDITABLE.filter(k => task.supplied.has(k) && !['due_date','status','date_inferred','timing_note','scheduled'].includes(k));
    const assignments = detailFields.map(k => k+'=excluded.'+k).concat([
      task.due_date_provided ? 'due_date=CASE WHEN tasks.due_date_manual=0 THEN excluded.due_date ELSE tasks.due_date END' : 'due_date=tasks.due_date',
      task.due_date_provided ? 'date_inferred=CASE WHEN tasks.due_date_manual=0 THEN excluded.date_inferred ELSE tasks.date_inferred END' : 'date_inferred=tasks.date_inferred',
      task.due_date_provided ? 'timing_note=CASE WHEN tasks.due_date_manual=0 THEN excluded.timing_note ELSE tasks.timing_note END' : 'timing_note=tasks.timing_note',
      task.status_provided ? 'status=CASE WHEN tasks.status_manual=0 THEN excluded.status ELSE tasks.status END' : 'status=tasks.status',
      'updated_at=excluded.updated_at'
    ]);
    statements.push(insertStatement(db,row,' ON CONFLICT(user_id,source_key) DO UPDATE SET '+assignments.join(',')+' WHERE tasks.deleted_at IS NULL'));
  }
  // D1 executes a batch as one transaction. A failed statement rolls back all.
  await db.batch(statements);
  return counts;
}

export async function handleRequest(request,env,page) {
  const u=new URL(request.url),method=request.method;
  // The existing private Sites ingress supplies this trusted header. Never use a
  // client-supplied body/query owner, public API key, or a new unauthenticated URL.
  const user=request.headers.get('oai-authenticated-user-id');
  if (!user) return json({error:'Please sign in to open your private task calendar.'},401);
  if (!['GET','HEAD'].includes(method)) {
    if (request.headers.get('origin') && request.headers.get('origin') !== u.origin) return json({error:'Origin check failed.'},403);
    if (request.headers.get('sec-fetch-site') === 'cross-site') return json({error:'Cross-site writes are not allowed.'},403);
  }
  if (u.pathname === '/' && ['GET','HEAD'].includes(method)) return new Response(method === 'HEAD' ? null : page,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'private, no-store','x-content-type-options':'nosniff'}});
  if (!u.pathname.startsWith('/api/')) return json({error:'Not found.'},404);
  if (!env?.DB) return json({error:'Task storage is not connected. Preserve and reconnect the existing DB binding.'},503);
  try {
    if (u.pathname === '/api/tasks') {
      if (method === 'GET') return json(await list(env.DB,user));
      if (method === 'POST') {
        const body=await readJson(request),task=parseTask(body),now=new Date().toISOString();
        if (!task.scheduled && !OWN(body,'due_date')) {
          task.date_inferred=true;
          if (!task.timing_note) task.timing_note='Proposed for today by default; choose a day to assign this suggestion.';
        }
        const row={...task,user_id:user,id:crypto.randomUUID(),legacy_key:null,source_key:null,due_date_manual:1,status_manual:1,created_at:now,updated_at:now};
        await insertStatement(env.DB,row).run();
        return json(publicTask(row),201);
      }
      return json({error:'Method not allowed.'},405);
    }
    if (u.pathname === '/api/import-review') {
      if (method !== 'POST') return json({error:'Method not allowed.'},405);
      return json(await importReview(env.DB,user,await readJson(request)));
    }
    if (u.pathname.startsWith('/api/tasks/')) {
      let id;
      try { id=decodeURIComponent(u.pathname.slice('/api/tasks/'.length)); } catch { throw new InputError('Invalid task ID.'); }
      if (!id || id.includes('/') || id.length > 300) throw new InputError('Invalid task ID.');
      if (!['PATCH','PUT','DELETE'].includes(method)) return json({error:'Method not allowed.'},405);
      const existing=await find(env.DB,user,id);
      if (!existing) return json({error:'Task not found.'},404);
      if (method === 'DELETE') {
        const now=new Date().toISOString();
        await env.DB.prepare('UPDATE tasks SET deleted_at=?,updated_at=? WHERE user_id=? AND id=? AND deleted_at IS NULL').bind(now,now,user,id).run();
        return new Response(null,{status:204,headers:{'cache-control':'private, no-store'}});
      }
      const body=await readJson(request),task=parseTask(body,existing);
      if (existing.source_key && ((OWN(body,'source_system') && canonicalSource(task.source_system) !== canonicalSource(existing.source_system)) || (OWN(body,'source_record') && task.source_record !== existing.source_record))) throw new InputError('Imported source identity cannot be changed. Edit task details without changing source_system or source_record.');
      if (OWN(body,'scheduled') && body.scheduled && !existing.scheduled && !OWN(body,'due_date')) throw new InputError('Choose an explicit due_date when assigning a suggested task to the calendar.');
      // Partial SQL updates keep unrelated changes from another device intact.
      const changes=EDITABLE.filter(k => OWN(body,k));
      if (!changes.length) throw new InputError('Provide a task field to update.');
      if (OWN(body,'due_date')) {
        // Choosing a date protects the owner's schedule. Its inference label is
        // independent: retain explicit labels, while a plain Move clears them.
        if (!OWN(body,'date_inferred')) task.date_inferred=false;
        if (!OWN(body,'timing_note')) task.timing_note=task.date_inferred ? task.timing_note : 'Date chosen manually.';
        if (!changes.includes('date_inferred')) changes.push('date_inferred');
        if (!changes.includes('timing_note')) changes.push('timing_note');
        // Legacy Move clients provide only a date. Explicit scheduled:false
        // instead edits a suggestion's proposed date without assigning it.
        if (!OWN(body,'scheduled')) task.scheduled=true;
        if (!changes.includes('scheduled')) changes.push('scheduled');
      }
      const assignments=changes.map(k => k+'=?'),values=changes.map(k => ['date_inferred','scheduled'].includes(k) ? Number(task[k]) : task[k]);
      if (OWN(body,'due_date')) {
        assignments.push('due_date_manual=1');
      }
      if (OWN(body,'status')) assignments.push('status_manual=1');
      assignments.push('updated_at=?'); values.push(new Date().toISOString(),user,id);
      await env.DB.prepare('UPDATE tasks SET '+assignments.join(',')+' WHERE user_id=? AND id=? AND deleted_at IS NULL').bind(...values).run();
      const updated=await find(env.DB,user,id);
      return updated ? json(publicTask(updated)) : json({error:'Task not found.'},404);
    }
    return json({error:'Not found.'},404);
  } catch (error) {
    if (error instanceof InputError) return json({error:error.message,...(error.details.length ? {details:error.details} : {})},400);
    if (/no such (column|table)|has no column/i.test(String(error?.message))) return json({error:'The calendar database needs the additive 0001_review_imports and 0002_task_scheduling migrations, in that order. Apply them through the existing Site’s authenticated D1 workflow; do not replace the database.'},503);
    return json({error:'Could not load or save tasks. Please try again.'},500);
  }
}
