# PSS Follow-up Calendar

Source for the existing private Premium Surface Solutions task calendar:
https://pss-morning-sales.vigilantbanjo.chatgpt.site

The original sanitized ZIP is the baseline. It contains no customer task seeds,
live database rows, credentials, or Git history. This update keeps the original
`.openai/hosting.json` unchanged:

- Site project: `appgprj_6aea78eba9b4819182ed8393975248bb`
- Existing D1 binding: `DB`
- No second Site or database; no audience configuration changes.

## Develop and validate

Use Node.js 24 (including its built-in SQLite module), npm, and Bash. There are no
third-party runtime dependencies and no installation step.

```sh
npm test
npm run build
npm run validate
npm run dev
```

The development server listens only on loopback port 8787. It uses an isolated,
ignored `.local/calendar.sqlite` database and a development-only `local-nico`
identity. It never connects to the live D1 database or any sales system. Migrations
run once per local database; restarting preserves local development tasks.
`PSS_LOCAL_DB` and `PSS_LOCAL_PORT` can select another local database and port.
Never deploy `scripts/dev-server.mjs`; the production entry is `worker/index.js`.

`npm run build` writes the ESM Worker modules, the preserved hosting manifest,
and schema migrations to `dist/`. `npm run validate` imports the built Worker,
checks the project ID and DB binding, and verifies that unauthenticated access
is rejected. `npm test` exercises authenticated APIs against actual local SQLite.
Browser smoke checks are in `tests/calendar-browser.py` and require Python
Playwright and Chromium. Run `python3 tests/calendar-browser.py`; it starts and
stops its own loopback server on port 8790 with a temporary SQLite database.
An existing development server is not needed. Set `PSS_BROWSER_TEST_PORT` to use
another unused local port. The test removes its temporary database on exit.

## Calendar behavior

Tasks live in D1 and are scoped by the signed-in user's trusted Sites identity.
No browser localStorage is used. Every task defaults to today in America/Denver
unless a date is explicitly chosen. New daily-review recommendations enter
**Suggested tasks** before they are assigned to the calendar. Their proposed
dates are guidance, not active deadlines. Choose **Today**, **Assign day**, or
drag a suggestion onto a calendar day to schedule it. **Add suggestion** lets
Nico enter an unscheduled follow-up directly; **Add task** schedules one immediately.

Assigned dates remain on their chosen days. The week
calendar supports date selection on mobile, previous/next week, Today, and
desktop dragging. Moving by date also works on touch devices.

Completed, sold, and not-happening tasks leave the active calendar and remain
available in the closed view. Open overdue tasks show their original dates.
Editing, moving, changing status, and deleting affect only this dashboard.
Unassigned suggestions never count as overdue. **Back to suggestions** removes
an open task from the calendar without deleting its context. Closing and reopening
a task retains whether it was assigned or suggested.

While visible, the dashboard reads its owner's saved D1 tasks automatically every
30 seconds and when the tab regains focus or visibility. Background refresh pauses
while editing a task, choosing a date, importing a review, or saving changes.
This displays suggestions written by another authenticated session without a
manual reload. It does not generate a sales review or deliver a ChatGPT task's
output into D1.

## Daily review imports

Use **Import review** in the signed-in private calendar to paste or upload a JSON
batch, review the preview, and import it. `POST /api/import-review` uses the same
existing Sites authentication as task edits; it is not an anonymous write route.
Do not expose it through a separate public endpoint, add tokens to URLs, or
invent a user-ID header from an external client.

See [IMPORT-FORMAT.md](IMPORT-FORMAT.md) for the payload and source rules. Imports
use a stable key derived from source system and source record, scoped by user.
Repeat reviews update details, preserve manually chosen dates/statuses, and
do not assign, unassign, or resurrect existing tasks. Existing tasks retain their pre-update dates and
statuses because the old schema did not record which choices were manual.
An omitted review date does not move an existing task forward to today.

The import endpoint validates the ownership/provenance supplied in the review.
It cannot independently verify Wingmate, Jobber, Quo, Gmail, or PSS Connect.
The upstream review must perform those read-only checks before export. No code
here writes to those systems or sends messages. A direct ChatGPT/Site MCP import
tool or scheduled daily-review delivery is not included in the supplied source
and was unavailable in this coding environment. Without such an authenticated
integration, JSON imports require the owner's action in the calendar.

For a **scheduled ChatGPT daily review**, automatic loading requires two parts:
the scheduled task must use a supported owner-authenticated Site import action
to deliver its verified batch, and the dashboard must refresh its stored tasks.
Only the refresh and duplicate-safe receiving API are implemented in this source.
This environment has no tools for inspecting/editing scheduled ChatGPT tasks or
configuring a Site MCP import action. Do not substitute an anonymous webhook,
put credentials in the browser, forge the hosting identity header, or claim that
polling the calendar reads a ChatGPT conversation.

## Update the existing private Site

Use the existing Site's owner-authenticated Sites deployment workflow. The
source package does not contain deployment credentials or access settings.

1. Inspect the deployed project, its current audience, D1 schema, and current
   migration state. Preserve the existing URL, project ID, audience, and database.
2. Before deploying the updated Worker, apply any unapplied additive migrations
   `drizzle/0001_review_imports.sql` and `drizzle/0002_task_scheduling.sql` in order,
   **once each**, to the existing `DB` through its authenticated migration workflow.
   Migration 0002 leaves all existing calendar tasks assigned to their current days.
   Do not create a replacement
   database, drop tables, seed customer tasks, or rerun an already-applied
   `ALTER TABLE` migration. Existing rows stay intact.
3. Run the build, tests, and artifact validator above. Publish `dist/` to the
   existing project. Omit access/audience changes.
4. Verify the existing URL with the owner's session: week/mobile navigation,
   suggested tasks and assignment, edit/move/status/delete, closed history,
   and duplicate-safe review imports.
   Confirm that signed-out users cannot read or write tasks.

Production migrations and deployment have not been executed by this package.
Local tests do not establish live Sites identity handling or live D1 readiness.

## Put this source in the existing GitHub repository

Use `Nicobraz/Daily-Sales-to-do` on `main`. Upload the project contents at the
repository root, including the hidden `.openai/hosting.json` file. Keep the
repository private. Exclude `.local/`, `dist/`, credentials, customer records,
and database exports. The supplied source needs no GitHub Actions secrets.
