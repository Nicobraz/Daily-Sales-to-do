CREATE TABLE IF NOT EXISTS user_settings (
  user_id TEXT PRIMARY KEY NOT NULL,
  seed_version INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  user_id TEXT NOT NULL,
  id TEXT NOT NULL,
  legacy_key TEXT,
  contact TEXT NOT NULL,
  company TEXT NOT NULL DEFAULT '',
  rep TEXT NOT NULL DEFAULT '',
  due_date TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'Medium',
  why TEXT NOT NULL DEFAULT '',
  next_action TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL DEFAULT '',
  source_system TEXT NOT NULL DEFAULT '',
  source_record TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL DEFAULT '',
  extra_url TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','done','sold','not_happening')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, id)
);

CREATE INDEX IF NOT EXISTS tasks_user_due_date ON tasks(user_id, due_date, status);
CREATE INDEX IF NOT EXISTS tasks_user_legacy_key ON tasks(user_id, legacy_key);
