-- Apply once through the existing Site's authenticated D1 migration workflow.
-- Existing rows remain intact. Their dates/statuses are conservatively protected
-- because the old schema cannot tell which values the owner previously changed.
ALTER TABLE tasks ADD COLUMN last_interaction_date TEXT NOT NULL DEFAULT '';
ALTER TABLE tasks ADD COLUMN date_inferred INTEGER NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN timing_note TEXT NOT NULL DEFAULT '';
ALTER TABLE tasks ADD COLUMN due_date_manual INTEGER NOT NULL DEFAULT 1;
ALTER TABLE tasks ADD COLUMN status_manual INTEGER NOT NULL DEFAULT 1;
ALTER TABLE tasks ADD COLUMN source_key TEXT;
ALTER TABLE tasks ADD COLUMN deleted_at TEXT;

-- NULL keys on existing/manual tasks do not conflict. Imports adopt a matching
-- legacy row before inserting, without deleting or merging any existing rows.
CREATE UNIQUE INDEX tasks_user_source_key ON tasks(user_id, source_key);
