-- Apply once after 0001_review_imports through the existing Site's D1 workflow.
-- Existing calendar assignments, dates, statuses, and task identities stay intact.
-- For scheduled=0, due_date is a proposed date only, not a calendar assignment.
ALTER TABLE tasks ADD COLUMN scheduled INTEGER NOT NULL DEFAULT 1 CHECK(scheduled IN (0,1));
