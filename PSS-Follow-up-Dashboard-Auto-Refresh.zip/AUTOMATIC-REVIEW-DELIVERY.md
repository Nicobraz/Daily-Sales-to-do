# Connect the scheduled ChatGPT daily sales review

The user confirmed that a scheduled ChatGPT task produces the daily review.
The calendar must receive that task's recommendations automatically, then leave
them in Suggested tasks until Nico assigns a day. Manual daily copying is not
the intended workflow.

## Existing destination

- Site: https://pss-morning-sales.vigilantbanjo.chatgpt.site
- Existing project: `appgprj_6aea78eba9b4819182ed8393975248bb`
- Existing D1 binding: `DB`
- Receiving route: `POST /api/import-review`, JSON `{ "tasks": [...] }`
- Receiving authentication: the existing trusted Sites owner identity.

The supplied source includes this authenticated receiving API and dashboard
auto-refresh. It does not include a supported Site MCP registration, a ChatGPT
scheduled-task configuration, or credentials that let a scheduled task invoke
the receiving route. This coding environment exposes none of those management
tools. A saved source ZIP or a published cloud workspace cannot establish that
connection.

## One-time work in a context with the required tools

First confirm the correct source version. The original uploaded
`PSS-Follow-up-Dashboard-Source.zip` is an older export and does **not** contain
the review receiver. Use `PSS-Follow-up-Dashboard-Auto-Refresh.zip`. It includes
`worker/api.js`, where `handleRequest` handles `/api/import-review`, and
`worker/index.js`, which imports that handler. The build copies both modules into
`dist/server/`. Do not search only the original monolithic `worker/index.js` or
assume a GitHub checkout contains the source before it has been committed there.

The updated source's hosting manifest still has **no MCP declaration**. Loading
or publishing the updated HTTP receiver does not register a ChatGPT tool. The
Site-capable context must implement/register the owner-authenticated action using
its actual supported Sites schema and workflow; do not guess manifest fields.

1. Inspect the existing scheduled daily-review task and preserve its schedule,
   authorized data sources, ownership rules, and existing reporting behavior.
2. Inspect the existing private Site and its supported owner-authenticated
   import/MCP workflow. Reuse an existing import action if available; otherwise
   configure one through the supported Sites workflow. Its authenticated caller
   must map to the same signed-in owner who uses the dashboard.
   Compare the deployed source with the updated ZIP, apply only unapplied
   migrations in order, and publish the updated receiver to the same project
   before testing the action. Preserve all existing rows and audience settings.
3. Add an automatic delivery step after the review is produced. Send at most
   100 verified, canonical follow-ups per batch to the existing receiving API
   through that supported import action. See `IMPORT-FORMAT.md` for fields.
4. Run the scheduled task's real authenticated delivery once and verify its
   response and resulting owner-scoped D1 rows. Confirm the suggestions appear
   in the existing dashboard within 30 seconds while the tab is visible.
5. Repeat the same verified batch. Confirm it updates existing records without
   duplicating tasks, changing assignments/manual dates/statuses, or resurrecting
   deleted follow-ups. Confirm another owner cannot see or edit those rows.

For read-only route diagnosis in an already authenticated owner browser session,
`GET /api/import-review` returns 405 when the current receiver and DB binding are
available. A 404 suggests a different route/source; a 503 indicates a storage
prerequisite. A 401 by itself does not prove route presence because the app's
authentication gate also protects unknown API paths. Do not forge identity
headers for remote diagnosis.

Do not invent a tool name, assume the scheduler can reuse a browser cookie, forge
the hosting identity header, add an anonymous webhook, or publish a second Site.
Preserve the current private audience, project, and D1 data. If the supported
authenticated import action is unavailable, report delivery as blocked rather
than saying the review has been synchronized.

## Instruction to add to the scheduled task once the import action exists

> After each daily sales review, automatically save every eligible recommended
> follow-up into Suggested tasks on my existing private PSS dashboard at
> https://pss-morning-sales.vigilantbanjo.chatgpt.site using its supported
> owner-authenticated Site import action. Use a stable canonical source system
> and source record ID. Include verified source links, contact/company, assigned
> rep, last interaction date when known, reason, priority, next action, and
> suggested message. Preserve any explicit review timing as a proposed date;
> leave new tasks unassigned until I choose a calendar day. Never reset my
> scheduling choices, manual dates, completion statuses, or deletions.
>
> Use only Nico's records. Wingmate leads must be assigned to Nico / Nico
> Braswell. Jobber ownership must be available and explicitly Nico or linked to
> a confirmed Nico-assigned lead. Read only Nico's Quo inbox; cross-reference
> unsaved caller numbers against Nico-owned Wingmate/Jobber records and leave
> unmatched callers unidentified. Cross-check authorized Gmail, Jobber,
> Wingmate, PSS Connect, and Quo activity to consolidate duplicates and avoid
> obsolete follow-ups after replies. Do not invent interactions, promises, or
> dates; label inferred proposed timing. Never send messages or modify any of
> those sales systems. Write only to the private dashboard.
>
> Verify the import action's result and report created, updated, and skipped
> counts. If the action or a required data source is unavailable, state exactly
> what was not saved or checked. Do not claim automatic delivery succeeded.

This instruction is a handoff for the existing scheduled task. It has not been
applied to that task by this coding environment.
