# More suggestions: UI-only update for the existing PSS Site

The user requested a separate tab with at least ten Nico-specific follow-ups
from the daily review. These are real review records, not reusable task ideas.

This package is a UI merge for the existing Site at
https://pss-morning-sales.vigilantbanjo.chatgpt.site, project
`appgprj_6aea78eba9b4819182ed8393975248bb`. It intentionally excludes the old
hosting manifest, API module, migrations, deployment output, credentials, and
customer data so it cannot overwrite the newer live MCP/OAuth integration.

## Behavior

- More suggestions shows open, unassigned, review-backed follow-ups. Manually
  entered suggestions remain available in the calendar's Suggested tasks list.
- It shows the available real records, including at least ten when ten are
  present. A shortfall is shown honestly; the UI never creates filler records.
- Assigning Today or another day updates the same owner-scoped D1 task.
- Closed and assigned tasks leave this tab. Existing task details, source links,
  editing, outcome actions, and deletions remain available.
- Opening the tab does not generate new review data. The existing scheduled
  review and its authenticated `import_review` action supply those records.

## Apply to the current Site source

Use the Site-enabled conversation/workflow. First inspect/export the **current**
Site source and its deployment metadata. Do not deploy the older full source ZIP
over the current MCP-enabled Site.

```sh
node /path/to/ui-update/scripts/apply-more-suggestions.mjs /path/to/current-pss-source
```

The helper requires the existing project ID and `DB` binding. It replaces only
the known HTML PAGE declaration inside `worker/index.js`, preserves everything
outside that declaration, and saves a backup in `.local/ui-backups`. It is
idempotent. If the live UI has diverged, it stops without changing that file;
merge `ui-updates/more-suggestions/ui.diff` manually into the current UI instead.
If the current app uses a different structure, implement the same UI changes in
that structure without replacing its backend or deployment configuration.

Run the current Site's build, validation, and relevant browser tests. Publish to
the same Site with its existing audience and DB. There are no new database
migrations for this tab. Confirm the existing `import_review` action still works.

## Update the review's target once

Append this instruction to the existing twice-daily sales review while preserving
its schedule, source permissions, ownership rules, and existing reporting:

> Identify at least ten eligible Nico-specific follow-ups per review when the
> authorized records support that many. Read the latest interactions and exclude
> obsolete follow-ups after replies. Use only Nico-assigned Wingmate leads;
> Jobber records need available ownership and explicit Nico ownership or a
> confirmed Nico-assigned linked lead. Read only Nico's Quo inbox and leave
> unmatched unsaved callers unidentified. Cross-check authorized Gmail, Jobber,
> Wingmate, PSS Connect, and Quo activity and consolidate duplicate records.
> Automatically upsert eligible recommendations through the existing dashboard
> import_review action as unassigned suggestions. Preserve manual assignments,
> dates, statuses, and deletions. Do not invent contacts, interactions, promises,
> or dates to reach ten. If fewer qualify, report the actual count and shortfall.
> Report the import action's actual created, updated, and skipped counts. Never
> send messages or modify the source sales systems.

This coding environment cannot edit that scheduled task or publish the Site.
Applying this UI patch does not itself change the review instructions or import
any real customer follow-ups.
