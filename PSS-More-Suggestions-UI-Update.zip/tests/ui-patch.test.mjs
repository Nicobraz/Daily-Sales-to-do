import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFile, writeFile, mkdir, mkdtemp, rm, readdir, symlink, copyFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { applyUiUpdate, pageRange } from '../scripts/apply-more-suggestions.mjs';

const bundle = fileURLToPath(new URL('../ui-updates/more-suggestions', import.meta.url));
const beforePage = await readFile(resolve(bundle, 'before-page.txt'), 'utf8');
const afterPage = await readFile(resolve(bundle, 'after-page.txt'), 'utf8');
const prefix = '// Existing deployment imports and MCP configuration stay here.\n';
const suffix = '\n// Existing owner-authenticated MCP handling stays here.\nexport default { fetch() { return new Response(PAGE); } };\n';

async function fixture(t, overrides = {}) {
  const root = await mkdtemp(resolve(tmpdir(), 'pss-ui-merge-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(resolve(root, 'worker'));
  await mkdir(resolve(root, '.openai'));
  const hosting = JSON.stringify({project_id:'appgprj_6aea78eba9b4819182ed8393975248bb',d1:'DB',preserved_metadata:{current:true},...overrides});
  await writeFile(resolve(root, '.openai/hosting.json'), hosting);
  await writeFile(resolve(root, 'worker/index.js'), prefix + beforePage + suffix);
  await writeFile(resolve(root, 'worker/api.js'), 'export const currentApi = "preserve";\n');
  return { root, hosting };
}

test('UI update preserves current runtime outside PAGE, hosting metadata, and API source', async t => {
  const { root, hosting } = await fixture(t);
  const response = await applyUiUpdate(root);
  assert.equal(response.changed, true);
  assert.equal(await readFile(resolve(root, 'worker/index.js'), 'utf8'), prefix + afterPage + suffix);
  assert.equal(await readFile(resolve(root, '.openai/hosting.json'), 'utf8'), hosting);
  assert.equal(await readFile(resolve(root, 'worker/api.js'), 'utf8'), 'export const currentApi = "preserve";\n');
  assert.equal(await readFile(response.backup, 'utf8'), prefix + beforePage + suffix);
});

test('reapplying is a no-op and preserves newer runtime changes outside PAGE', async t => {
  const { root } = await fixture(t);
  await applyUiUpdate(root);
  const source = await readFile(resolve(root, 'worker/index.js'), 'utf8') + '// Later runtime change.\n';
  await writeFile(resolve(root, 'worker/index.js'), source);
  assert.equal((await applyUiUpdate(root)).changed, false);
  assert.equal(await readFile(resolve(root, 'worker/index.js'), 'utf8'), source);
  assert.equal((await readdir(resolve(root, '.local/ui-backups'))).length, 1);
});

test('a diverged live UI stops the merge without overwriting current source', async t => {
  const { root } = await fixture(t);
  const source = prefix + beforePage.replace('Follow-up calendar', 'Current live calendar') + suffix;
  assert.notEqual(source, prefix + beforePage + suffix);
  await writeFile(resolve(root, 'worker/index.js'), source);
  await assert.rejects(applyUiUpdate(root), /differs from the known baseline/);
  assert.equal(await readFile(resolve(root, 'worker/index.js'), 'utf8'), source);
  await assert.rejects(readdir(resolve(root, '.local')), {code:'ENOENT'});
});

test('a different Site or database binding is rejected without changing its source', async t => {
  for (const overrides of [{project_id:'another-project'},{d1:'ANOTHER_DB'}]) {
    const { root } = await fixture(t, overrides);
    await assert.rejects(applyUiUpdate(root), /existing PSS Site/);
    assert.equal(await readFile(resolve(root, 'worker/index.js'), 'utf8'), prefix + beforePage + suffix);
  }
});

test('a corrupted patch payload fails checksum verification before source writes', async t => {
  const { root } = await fixture(t);
  const changedBundle = resolve(root, 'corrupt-bundle');
  await mkdir(changedBundle);
  await copyFile(resolve(bundle, 'patch.json'), resolve(changedBundle, 'patch.json'));
  await writeFile(resolve(changedBundle, 'after-page.txt'), afterPage + 'corruption');
  await assert.rejects(applyUiUpdate(root, changedBundle), /checksum mismatch/);
  assert.equal(await readFile(resolve(root, 'worker/index.js'), 'utf8'), prefix + beforePage + suffix);
});

test('symlink targets and unsupported UI structures are not overwritten', async t => {
  const { root } = await fixture(t);
  const target = resolve(root, 'worker/index.js');
  const other = resolve(root, 'original-runtime.js');
  await writeFile(other, prefix + beforePage + suffix);
  await rm(target);
  await symlink(other, target);
  await assert.rejects(applyUiUpdate(root), /nonregular/);
  assert.equal(await readFile(other, 'utf8'), prefix + beforePage + suffix);
  assert.throws(() => pageRange('export default { fetch() {} };'), /supported PAGE/);
});
