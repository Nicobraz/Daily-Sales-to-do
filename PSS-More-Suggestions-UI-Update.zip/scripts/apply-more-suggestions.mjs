import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, realpath, lstat, rename, unlink } from 'node:fs/promises';
import { dirname, resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

// A guarded UI merge, not a deployment command. Never writes hosting, API, or DB files.
const sha256 = value => createHash('sha256').update(value).digest('hex');
export function pageRange(source) {
  const marker = 'const PAGE = String.raw`';
  const start = source.indexOf(marker);
  if (start < 0 || source.indexOf(marker, start + marker.length) !== -1) {
    throw new Error('Expected one supported PAGE template. No files changed; merge the UI diff into the current Site source manually.');
  }
  for (let position = start + marker.length; position < source.length; position++) {
    if (source[position] !== '`') continue;
    let slashes = 0;
    for (let back = position - 1; source[back] === '\\'; back--) slashes++;
    if (slashes % 2) continue;
    let end = position + 1;
    while (/\s/.test(source[end] || '') && end < source.length) end++;
    if (source[end] !== ';') throw new Error('Unsupported PAGE declaration. No files changed.');
    return { start, end: end + 1, page: source.slice(start, end + 1) };
  }
  throw new Error('Unterminated PAGE template. No files changed.');
}

export async function applyUiUpdate(targetDirectory, bundleDirectory = resolve(dirname(fileURLToPath(import.meta.url)), '../ui-updates/more-suggestions')) {
  const root = await realpath(targetDirectory);
  const target = resolve(root, 'worker/index.js');
  const manifest = JSON.parse(await readFile(resolve(bundleDirectory, 'patch.json'), 'utf8'));
  const hosting = JSON.parse(await readFile(resolve(root, '.openai/hosting.json'), 'utf8'));
  if (hosting.project_id !== manifest.project_id || hosting.d1 !== 'DB') {
    throw new Error('The target must be the existing PSS Site with its DB binding. No files changed.');
  }
  const info = await lstat(target);
  if (!info.isFile() || info.isSymbolicLink()) throw new Error('Refusing to replace a nonregular UI source file.');
  const location = relative(root, await realpath(target));
  if (location.startsWith('..') || isAbsolute(location)) throw new Error('UI source must stay inside the target project.');
  const source = await readFile(target, 'utf8');
  const { start, end, page } = pageRange(source);
  if (sha256(page) === manifest.after_sha256) return { changed: false, message: 'More suggestions is already applied. No files changed.' };
  if (sha256(page) !== manifest.before_sha256) {
    throw new Error('The current Site UI differs from the known baseline. No files changed. Merge ui-updates/more-suggestions/ui.diff into the current source manually, preserving its MCP handlers and configuration.');
  }
  const replacement = await readFile(resolve(bundleDirectory, 'after-page.txt'), 'utf8');
  if (sha256(replacement) !== manifest.after_sha256) throw new Error('UI payload checksum mismatch. No files changed.');
  const next = source.slice(0, start) + replacement + source.slice(end);
  const backupDirectory = resolve(root, '.local/ui-backups');
  await mkdir(backupDirectory, { recursive: true });
  const backup = resolve(backupDirectory, `index-before-more-suggestions-${sha256(source).slice(0, 12)}.js`);
  try { await writeFile(backup, source, { flag: 'wx', mode: info.mode & 0o777 }); }
  catch (error) {
    if (error.code !== 'EEXIST' || await readFile(backup, 'utf8') !== source) throw error;
  }
  const temporary = resolve(dirname(target), `.index-more-suggestions-${randomUUID()}.tmp`);
  try {
    await writeFile(temporary, next, { flag: 'wx', mode: info.mode & 0o777 });
    if (await readFile(target, 'utf8') !== source) throw new Error('The UI changed during the merge. The original file was not overwritten.');
    await rename(temporary, target);
  } finally {
    await unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; });
  }
  return { changed: true, backup, message: 'Merged the More suggestions UI. Hosting, API handlers, MCP/OAuth configuration, database migrations, and data were not changed.' };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (!process.argv[2]) {
    console.error('Usage: node scripts/apply-more-suggestions.mjs /path/to/current-pss-source');
    process.exitCode = 1;
  } else {
    try { console.log((await applyUiUpdate(process.argv[2])).message); }
    catch (error) { console.error(error.message); process.exitCode = 1; }
  }
}
